function run_STAR_GenSSI_structural_identifiability(genssi_root, varargin)
%RUN_STAR_GENSSI_STRUCTURAL_IDENTIFIABILITY Analyze the single STAR model.
%
% This script runs GenSSI 2.0 for the same single STAR ODE model used in
% the synthetic-data calibration. It assumes one 8 nM STAR-plasmid condition,
% a known 0.5 nM target-plasmid concentration, zero initial states, and mature
% GFP as the ONLY measured output.
%
% The analysis is analytical/structural: it assumes an exact continuous GFP
% output trajectory and does not use synthetic replicates, any optimization
% objective, fitted parameters, or measurement variance. It answers whether
% the model structure and GFP-only observation are sufficient to uniquely
% distinguish the eight kinetic parameters or only parameter combinations.
%
% Installation and use
% --------------------
% Download GenSSI 2.0 from https://github.com/genssi-developer/GenSSI and run:
%
%   addpath('path/to/star_rebuild');
%   run_STAR_GenSSI_structural_identifiability('path/to/GenSSI');
%
% GenSSI writes its own reports and tableau figures beneath its Examples
% directory. Archive those reports with the manuscript analysis files.

    ip = inputParser;
    ip.addRequired('genssi_root', @(x) ischar(x) || isstring(x));
    ip.addParameter('Nder', 12, @(x) isnumeric(x) && isscalar(x) && x >= 1);
    ip.addParameter('StoreResults', true, @(x) islogical(x) && isscalar(x));
    ip.parse(genssi_root, varargin{:});
    settings = ip.Results;

    genssi_root = char(settings.genssi_root);
    assert(isfolder(genssi_root), 'GenSSI folder not found: %s', genssi_root);
    assert(isfile(fullfile(genssi_root,'genssiStartup.m')), ...
        'The supplied folder is not a GenSSI installation: %s', genssi_root);

    this_folder = fileparts(mfilename('fullpath'));
    addpath(this_folder);
    addpath(genssi_root);
    genssiStartup;  % creates default configuration and adds GenSSI dependencies

    options = struct('verbose',true,'store',settings.StoreResults, ...
        'closeFigure',false,'reportCompTime',true,'noRank',false);

    % GenSSI versions differ in how they handle an explicitly empty third
    % argument. Pass the model's parameter vector explicitly so model.sym.Par
    % is always created before GenSSI writes its input report.
    star_model = STAR_GenSSI_Single8nM();

    fprintf('\n=== GenSSI: single STAR model (8 nM Ps; mature GFP only) ===\n');
    genssiMain('STAR_GenSSI_Single8nM', settings.Nder, star_model.sym.p, options);
    fprintf('\nGenSSI analysis completed. Inspect GenSSI''s text report and identifiability tableau.\n');
end

function model = STAR_GenSSI_Single8nM()
%STAR_GENSSI_SINGLE8NM Structural-identifiability specification for STAR.
%
% This is a symbolic GenSSI version of STAR_GenAlg_Model.m at the 8 nM
% STAR-plasmid calibration condition. The only observable is mature GFP
% (Gm), matching the actual parameterization study. All five dynamical
% states have known zero initial conditions. The output scaling factor 1e6
% used for fluorescence plots is intentionally omitted: multiplication of
% an observable by a known constant does not change structural
% identifiability.
%
% Unknown parameter vector:
% [alpha_s, delta_s, delta_m, beta_s, alpha_m, Ki, Ke, alpha_gm]
%
% Known experimental constants:
% Ps = 8 nM (STAR plasmid); Py = 0.5 nM (target plasmid).

    % State variables
    syms S Y Yi G Gm

    % Unknown kinetic parameters
    syms alpha_s delta_s delta_m beta_s alpha_m Ki Ke alpha_gm

    % Known experimental constants, expressed in molar units as in the
    % numerical MATLAB model. GenSSI treats only model.sym.p as unknown.
    Ps = sym(8e-9);
    Py = sym(0.5e-9);

    % Parameters to test for structural identifiability
    model.sym.p = [alpha_s; delta_s; delta_m; beta_s; ...
                   alpha_m; Ki; Ke; alpha_gm];

    % Dynamical states
    model.sym.x = [S; Y; Yi; G; Gm];

    % No freely varying continuous controls in the single-condition model.
    model.sym.g = [];

    % Autonomous STAR dynamics, matching STAR_GenAlg_Model.m.
    model.sym.xdot = [ ...
        alpha_s*Ps - delta_s*S - beta_s*S*Py; ...
        alpha_m*beta_s*S*Py - delta_m*Y - Ki*Y + Ke*Yi; ...
        Ki*Y - Ke*Yi; ...
        Ke*Yi - alpha_gm*G; ...
        alpha_gm*G];

    % Known zero initial state, matching the parameterization workflow.
    model.sym.x0 = [0; 0; 0; 0; 0];

    % The study measures only mature GFP.
    model.sym.y = [Gm];
end

function run_summary = run_STAR_experimental_four_condition_ga(csv_file,varargin)
%RUN_STAR_EXPERIMENTAL_FOUR_CONDITION_GA Jointly fit the four STAR conditions.
%
% The input CSV is the reorganized STAR_Data.csv layout:
%   - a metadata block before the row that begins with "Time";
%   - one Time column;
%   - nine replicate columns for STAR OFF, 4 nM, 8 nM, and 16 nM.
%
% One shared eight-parameter STAR kinetic vector is fitted jointly to all
% four conditions. The known STAR plasmid input par.Ps is changed per
% condition: 0, 4e-9, 8e-9, and 16e-9 M. The model states retain the same
% zero initial condition x0 = zeros(5,1), as defined by STAR_GenAlg_Model.
%
% Three objectives are evaluated with 30 independent GA restarts by default:
%   no_variance:       sum_{condition,time} residual^2
%   variance:          sum residual^2 / sample_variance
%   relative_variance: sum residual^2 / (sample_variance / sample_mean^2)
%
% Variance is calculated from the NINE replicate GFP values at each same
% time point, separately for every condition. Time zero is excluded from
% fitting by default because relative variance is undefined when mean GFP
% is zero or close to zero.
%
% Example diagnostic run:
%   run_STAR_experimental_four_condition_ga('STAR_Data.csv', ...
%       'NumRestarts',2,'PopulationSize',50,'MaxGenerations',30,'Display','iter', ...
%       'OutputDirectory','STAR_experimental_four_condition_diagnostic');
%
% Full manuscript-style run:
%   run_STAR_experimental_four_condition_ga('STAR_Data.csv', ...
%       'NumRestarts',30,'PopulationSize',100,'MaxGenerations',100,'Display','off', ...
%       'OutputDirectory','STAR_experimental_four_condition_results');

    ip = inputParser;
    ip.addRequired('csv_file',@(x)ischar(x)||isstring(x));
    ip.addParameter('ConditionLabels',{'STAR OFF','STAR 4nM','STAR 8nM','STAR 16nM'}, ...
        @(x)iscell(x)||isstring(x));
    ip.addParameter('STARPlasmidM',[0,4e-9,8e-9,16e-9], ...
        @(x)isnumeric(x)&&isvector(x)&&numel(x)==4&&all(x>=0));
    ip.addParameter('TargetPlasmidM',0.5e-9,@(x)isnumeric(x)&&isscalar(x)&&x>=0);
    ip.addParameter('OutputDirectory','STAR_experimental_four_condition_results',@(x)ischar(x)||isstring(x));
    ip.addParameter('NumRestarts',30,@(x)isnumeric(x)&&isscalar(x)&&x>=1);
    ip.addParameter('PopulationSize',100,@(x)isnumeric(x)&&isscalar(x)&&x>=8);
    ip.addParameter('MaxGenerations',100,@(x)isnumeric(x)&&isscalar(x)&&x>=1);
    ip.addParameter('FunctionTolerance',1e-8,@(x)isnumeric(x)&&isscalar(x)&&x>0);
    ip.addParameter('InitialPopulationScale','log10',@(x)any(strcmpi(x,{'log10','linear'})));
    ip.addParameter('VarianceFloor',1e-12,@(x)isnumeric(x)&&isscalar(x)&&x>0);
    ip.addParameter('SignalFloor',1e-6,@(x)isnumeric(x)&&isscalar(x)&&x>0);
    ip.addParameter('RelativeVarianceFloor',1e-12,@(x)isnumeric(x)&&isscalar(x)&&x>0);
    ip.addParameter('ExcludeTimeZero',true,@(x)islogical(x)&&isscalar(x));
    ip.addParameter('RandomSeed',20260906,@(x)isnumeric(x)&&isscalar(x));
    ip.addParameter('Resume',true,@(x)islogical(x)&&isscalar(x));
    ip.addParameter('Display','off',@(x)any(strcmpi(x,{'off','final','iter'})));
    ip.parse(csv_file,varargin{:});
    settings = ip.Results;

    assert(exist('STAR_GenAlg_Model.m','file')==2, ...
        'STAR_GenAlg_Model.m must be available on the MATLAB path.');
    assert(exist('ga','file')==2, ...
        'The Global Optimization Toolbox function ga is required.');

    conditions = read_STAR_four_condition_csv(char(csv_file), ...
        cellstr(string(settings.ConditionLabels)),settings.STARPlasmidM);
    n_conditions = numel(conditions);
    assert(n_conditions==4,'Exactly four conditions are required.');
    assert(all(conditions(1).time_min == conditions(end).time_min), ...
        'All conditions must have the same sampled time vector.');

    % These bounds and parameter ordering reproduce STAR_GA_Fitting.m.
    lb = [1e-1,1e-4,1e-4,1e3,1e-1,1e-3,1e-3,1e-3];
    ub = [1e1, 1e0, 1e0, 1e8,1e2, 1e-1,1e-1,1e-1];
    parameter_names = {'alpha_s','deg_s','deg_m','beta_s','alpha_m','K_i','K_e','alpha_gm'};
    objective_types = {'no_variance','variance','relative_variance'};

    time_min = conditions(1).time_min(:);
    fit_mask = time_min > 0;
    if ~settings.ExcludeTimeZero, fit_mask = true(size(time_min)); end
    common = struct( ...
        'time_sec',60.*time_min, ...
        'fit_mask',fit_mask, ...
        'x0',zeros(5,1), ...
        'target_plasmid_m',settings.TargetPlasmidM, ...
        'ode_options',odeset('RelTol',1e-8,'AbsTol',1e-10), ...
        'variance_floor',settings.VarianceFloor, ...
        'signal_floor',settings.SignalFloor, ...
        'relative_variance_floor',settings.RelativeVarianceFloor);

    output_dir = char(settings.OutputDirectory);
    if ~isfolder(output_dir), mkdir(output_dir); end
    checkpoint_file = fullfile(output_dir,'STAR_experimental_four_condition_checkpoint.mat');
    if settings.Resume && isfile(checkpoint_file)
        saved = load(checkpoint_file,'run_records');
        if isfield(saved,'run_records'), run_records = saved.run_records; else, run_records = empty_record_array(); end
    else
        run_records = empty_record_array();
    end

    fprintf('\n=== STAR: FOUR-CONDITION, THREE-OBJECTIVE CALIBRATION ===\n');
    fprintf('Conditions: %s\n',strjoin({conditions.display_name},', '));
    fprintf('Replicates/condition: %s\n',mat2str([conditions.n_replicates]));
    fprintf('Sampled times: %d (%g to %g min)\n',numel(time_min),min(time_min),max(time_min));
    fprintf('Shared kinetic parameters: %d; GA restarts/objective: %d\n\n',numel(lb),settings.NumRestarts);

    for objective_index = 1:numel(objective_types)
        objective_type = objective_types{objective_index};
        fprintf('%s\n',strrep(objective_type,'_',' '));
        for restart_id = 1:settings.NumRestarts
            if record_exists(run_records,objective_type,restart_id)
                fprintf('  Restart %2d: already complete; skipping.\n',restart_id);
                continue;
            end

            % Identical starting populations for the three objectives in a
            % given restart make the optimization comparison reproducible.
            run_seed = settings.RandomSeed + restart_id;
            rng(run_seed,'twister');
            initial_population = sample_initial_population(lb,ub,settings.PopulationSize,settings.InitialPopulationScale);
            p0 = initial_population(1,:);
            objective_handle = @(p) STAR_four_condition_objective(p,objective_type,conditions,common);
            ga_options = optimoptions('ga', ...
                'PopulationSize',settings.PopulationSize, ...
                'MaxGenerations',settings.MaxGenerations, ...
                'FunctionTolerance',settings.FunctionTolerance, ...
                'InitialPopulationMatrix',initial_population, ...
                'Display',settings.Display,'PlotFcn',[]);

            record = new_record(objective_type,restart_id,p0,run_seed);
            start_time = tic;
            try
                rng(run_seed,'twister');
                [p_opt,fval,exitflag,output] = ga(objective_handle,numel(lb),[],[],[],[],lb,ub,[],ga_options);
                [training_objective,common_sse,predictions] = ...
                    STAR_four_condition_objective(p_opt,objective_type,conditions,common);
                record.p_opt = p_opt(:)';
                record.fval = fval;
                record.training_objective = training_objective;
                record.common_sse = common_sse;
                record.exitflag = exitflag;
                record.output = output;
                record.predictions = predictions;
                record.status = 'success';
                record.message = '';
                fprintf('  Restart %2d: J = %.4e | common SSE = %.4e | exit = %d\n', ...
                    restart_id,training_objective,common_sse,exitflag);
            catch ME
                record.p_opt = nan(1,numel(lb));
                record.fval = inf;
                record.training_objective = inf;
                record.common_sse = inf;
                record.exitflag = -999;
                record.output = struct();
                record.predictions = nan(n_conditions,numel(time_min));
                record.status = 'failed';
                record.message = sprintf('%s: %s',ME.identifier,ME.message);
                fprintf('  Restart %2d: FAILED (%s)\n',restart_id,ME.message);
            end
            record.runtime_seconds = toc(start_time);
            run_records(end+1) = record; %#ok<AGROW>
            save(checkpoint_file,'run_records','conditions','settings','lb','ub','parameter_names','-v7.3');
        end
    end

    run_summary = summarize_runs(run_records,objective_types,parameter_names,lb,ub,conditions,settings);
    save(fullfile(output_dir,'STAR_experimental_four_condition_results.mat'), ...
        'run_records','run_summary','conditions','settings','lb','ub','parameter_names','-v7.3');
    write_summary_csv(run_summary,fullfile(output_dir,'STAR_experimental_four_condition_summary.csv'));
    fprintf('\nFinished. Results saved in: %s\n',output_dir);
end

function conditions = read_STAR_four_condition_csv(filename,required_labels,plasmid_values)
    assert(isfile(filename),'CSV file not found: %s',filename);
    raw = readcell(filename);
    n_rows = size(raw,1);
    n_cols = size(raw,2);

    % Locate the data header rather than assuming how many metadata rows occur.
    header_row = [];
    for row = 1:n_rows
        if is_text_equal(raw{row,1},'Time')
            header_row = row;
            break;
        end
    end
    assert(~isempty(header_row),'No data-header row beginning with "Time" was found.');

    header = strings(1,n_cols);
    for col = 1:n_cols, header(col) = strtrim(string(raw{header_row,col})); end
    assert(strcmpi(header(1),'Time'),'First data-header column must be Time.');

    time_values = cell_to_numeric_vector(raw(header_row+1:end,1));
    condition_matrix = cell_to_numeric_matrix(raw(header_row+1:end,2:end));
    valid_rows = isfinite(time_values) & any(isfinite(condition_matrix),2);
    time_min = time_values(valid_rows);
    condition_matrix = condition_matrix(valid_rows,:);
    [time_min,sort_order] = sort(time_min(:));
    condition_matrix = condition_matrix(sort_order,:);
    assert(all(diff(time_min)>0),'Time values must be unique and strictly increasing after metadata rows are removed.');

    conditions = repmat(struct( ...
    'display_name', '', ...
    'star_plasmid_m', NaN, ...
    'time_min', [], ...
    'replicates', [], ...
    'n_replicates', NaN, ...
    'mean_data', [], ...
    'sample_variance', [], ...
    'sample_sd', []), 1, numel(required_labels));
    for condition_index = 1:numel(required_labels)
        label = string(required_labels{condition_index});
        data_columns = find(strcmpi(header(2:end),label));
        assert(numel(data_columns)>=2, ...
            'Could not find at least two replicate columns labeled "%s".',label);
        data_columns = data_columns + 1; % compensate for removed Time location
        replicates = condition_matrix(:,data_columns-1)';
        valid_time = all(isfinite(replicates),1);
        assert(all(valid_time), ...
            'Condition "%s" has missing replicate values after its data header.',label);
        condition = struct();
        condition.display_name = char(label);
        condition.star_plasmid_m = plasmid_values(condition_index);
        condition.time_min = time_min;
        condition.replicates = replicates;
        condition.n_replicates = size(replicates,1);
        condition.mean_data = mean(replicates,1)';
        condition.sample_variance = var(replicates,0,1)';
        condition.sample_sd = sqrt(max(condition.sample_variance,0));
        conditions(condition_index) = condition;
    end
end

function values = cell_to_numeric_vector(cells)
    values = nan(numel(cells),1);
    for i = 1:numel(cells), values(i) = numeric_cell_value(cells{i}); end
end

function matrix = cell_to_numeric_matrix(cells)
    matrix = nan(size(cells));
    for i = 1:numel(cells)
        matrix(i) = numeric_cell_value(cells{i});
    end
end

function value = numeric_cell_value(cell_value)
    if isempty(cell_value)
        value = NaN;
    elseif isnumeric(cell_value) && isscalar(cell_value)
        value = double(cell_value);
    elseif islogical(cell_value) && isscalar(cell_value)
        value = double(cell_value);
    else
        value = str2double(string(cell_value));
    end
end

function tf = is_text_equal(cell_value,target)
    if ischar(cell_value) || isstring(cell_value)
        tf = strcmpi(strtrim(string(cell_value)),target);
    else
        tf = false;
    end
end

function [objective_value,common_sse,predictions] = STAR_four_condition_objective(p,objective_type,conditions,common)
    global par
    n_conditions = numel(conditions);
    n_time = numel(common.time_sec);
    predictions = nan(n_conditions,n_time);
    objective_value = 0;
    common_sse = 0;

    try
        for condition_index = 1:n_conditions
            condition = conditions(condition_index);
            par = struct('PYtot',common.target_plasmid_m,'Ps',condition.star_plasmid_m);
            [t_out,x_out] = ode23s(@(t,x) STAR_GenAlg_Model(t,x,p), ...
                common.time_sec,common.x0,common.ode_options);
            if numel(t_out)~=n_time || size(x_out,2)<5 || ~isreal(x_out) || any(~isfinite(x_out(:)))
                error('Invalid ODE solution in condition %s.',condition.display_name);
            end
            prediction = x_out(:,5).*1e6;
            if any(~isfinite(prediction)), error('Invalid GFP prediction.'); end
            predictions(condition_index,:) = prediction(:)';
            residual = prediction - condition.mean_data;
            valid = common.fit_mask & isfinite(residual) & isfinite(condition.sample_variance);
            if ~any(valid), error('No valid residuals in condition %s.',condition.display_name); end
            squared_residual = residual(valid).^2;
            common_sse = common_sse + sum(squared_residual);

            switch lower(objective_type)
                case 'no_variance'
                    objective_value = objective_value + sum(squared_residual);
                case 'variance'
                    denominator = max(condition.sample_variance(valid),common.variance_floor);
                    objective_value = objective_value + sum(squared_residual./denominator);
                case 'relative_variance'
                    relative_variance = condition.sample_variance(valid)./ ...
                        max(condition.mean_data(valid).^2,common.signal_floor);
                    denominator = max(relative_variance,common.relative_variance_floor);
                    objective_value = objective_value + sum(squared_residual./denominator);
                otherwise
                    error('Unknown objective type: %s',objective_type);
            end
        end
        if ~isfinite(objective_value) || ~isreal(objective_value), error('Invalid objective value.'); end
    catch
        objective_value = 1e10;
        common_sse = 1e10;
        predictions = nan(n_conditions,n_time);
    end
end

function population = sample_initial_population(lb,ub,population_size,scale)
    n_parameters = numel(lb);
    switch lower(scale)
        case 'log10'
            population = 10.^(log10(lb) + rand(population_size,n_parameters).*(log10(ub)-log10(lb)));
        case 'linear'
            population = lb + rand(population_size,n_parameters).*(ub-lb);
        otherwise
            error('Unknown InitialPopulationScale: %s',scale);
    end
end

function tf = record_exists(records,objective_type,restart_id)
    if isempty(records), tf = false; return; end
    tf = any(strcmp({records.objective_type},objective_type) & [records.restart_id]==restart_id);
end

function record = new_record(objective_type,restart_id,p0,seed)
    record = struct('objective_type',objective_type,'restart_id',restart_id, ...
        'p0',p0,'random_seed',seed,'p_opt',[],'fval',[], ...
        'training_objective',[],'common_sse',[],'exitflag',[], ...
        'output',[],'predictions',[],'runtime_seconds',[], ...
        'status','','message','');
end

function records = empty_record_array()
    prototype = new_record('',[],[],[]);
    records = prototype([]);
end

function summary = summarize_runs(records,objective_types,parameter_names,lb,ub,conditions,settings)
    summary = struct('objective_types',{objective_types},'parameter_names',{parameter_names}, ...
        'lower_bounds',lb,'upper_bounds',ub,'conditions',conditions,'settings',settings,'by_objective',struct());
    for i = 1:numel(objective_types)
        objective_type = objective_types{i};
        selected = records(strcmp({records.objective_type},objective_type) & strcmp({records.status},'success'));
        result = struct('n_successful_runs',numel(selected));
        if isempty(selected)
            result.best_by_training_objective = [];
            result.best_by_common_sse = [];
        else
            [~,idx_train] = min([selected.training_objective]);
            [~,idx_sse] = min([selected.common_sse]);
            result.best_by_training_objective = selected(idx_train);
            result.best_by_common_sse = selected(idx_sse);
            result.parameter_matrix = vertcat(selected.p_opt);
            result.training_objective = [selected.training_objective]';
            result.common_sse = [selected.common_sse]';
        end
        summary.by_objective.(objective_type) = result;
    end
end

function write_summary_csv(summary,output_file)
    headers = [{'Objective','SuccessfulRuns','BestTrainingObjective','CommonSSEofBestTrainingRun','BestCommonSSE'},summary.parameter_names];
    rows = cell(numel(summary.objective_types),numel(headers));
    for i = 1:numel(summary.objective_types)
        objective_type = summary.objective_types{i};
        result = summary.by_objective.(objective_type);
        rows{i,1} = objective_type;
        rows{i,2} = result.n_successful_runs;
        if isempty(result.best_by_training_objective)
            rows(i,3:end) = num2cell(nan(1,numel(headers)-2));
        else
            best_train = result.best_by_training_objective;
            best_sse = result.best_by_common_sse;
            rows{i,3} = best_train.training_objective;
            rows{i,4} = best_train.common_sse;
            rows{i,5} = best_sse.common_sse;
            rows(i,6:end) = num2cell(best_train.p_opt);
        end
    end
    writecell([headers;rows],output_file);
end

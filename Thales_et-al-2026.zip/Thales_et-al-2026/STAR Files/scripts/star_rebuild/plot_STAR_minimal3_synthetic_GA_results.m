function plot_STAR_minimal3_synthetic_GA_results(results_file,varargin)
%PLOT_STAR_MINIMAL3_SYNTHETIC_GA_RESULTS Plot minimal STAR synthetic results.
%
% Creates only the requested scientific outputs for the four-parameter
% minimal STAR model: a three-panel synthetic trajectory fit and a four-panel
% fitted-parameter distribution figure. The dashed synthetic mean is black.
% Filled boxes encode objective; only standard 1.5-IQR outliers are shown.

    ip=inputParser;
    ip.addRequired('results_file',@(x)ischar(x)||isstring(x));
    ip.addParameter('OutputDirectory','',@(x)ischar(x)||isstring(x));
    ip.addParameter('DataFile','Simulated_Data_Jan22_2025.mat',@(x)ischar(x)||isstring(x));
    ip.addParameter('SelectionCriterion','training_objective', ...
        @(x)any(strcmpi(x,{'training_objective','common_sse'})));
    ip.addParameter('Visible','on',@(x)any(strcmpi(x,{'on','off'})));
    ip.parse(results_file,varargin{:}); settings=ip.Results;

    source=load(settings.results_file,'run_records','param_names');
    assert(isfield(source,'run_records')&&~isempty(source.run_records), ...
        'No minimal-model fitting records found in %s.',settings.results_file);
    synthetic_input=load(settings.DataFile,'Simu_Traje','Simu_t');
    assert(isfield(synthetic_input,'Simu_Traje')&&isfield(synthetic_input,'Simu_t'), ...
        'DataFile must contain Simu_Traje and Simu_t.');
    if isempty(settings.OutputDirectory)
        [parent,~,~]=fileparts(settings.results_file); output_dir=fullfile(parent,'plots');
    else
        output_dir=char(settings.OutputDirectory);
    end
    if ~isfolder(output_dir), mkdir(output_dir); end

    objectives={'no_variance','variance','relative_variance'};
    labels={'No Variance','Variance','Relative Variance'};
    colors=[0.4940 0.1840 0.5560; 0.3010 0.7450 0.9330; 0.8500 0.3250 0.0980];
    parameter_labels={'\theta_{tx}','\beta_{bind}','\delta_{RNA}','\delta_G'};
    [time_min,data_mean,data_sd,prediction_groups,parameter_groups,summary_table]= ...
        collect_data(source.run_records,objectives,settings.SelectionCriterion,synthetic_input);

    %% Three-panel trajectory fit
    fit_fig=figure('Position',[10,10,2000,720],'Color','w','Visible',settings.Visible);
    for o=1:3
        ax=subplot(1,3,o); hold(ax,'on');
        pred=prediction_groups{o}; pred_mean=mean(pred,1,'omitnan'); pred_sd=std(pred,0,1,'omitnan');
        tf=[time_min,fliplr(time_min)];
        fill(ax,tf,[data_mean-data_sd,fliplr(data_mean+data_sd)], [0.55 0.72 0.85], ...
            'FaceAlpha',0.30,'EdgeColor','none','HandleVisibility','off');
        fill(ax,tf,[pred_mean-pred_sd,fliplr(pred_mean+pred_sd)], colors(o,:), ...
            'FaceAlpha',0.40,'EdgeColor','none','HandleVisibility','off');
        plot(ax,time_min,data_mean,'--','Color','k','LineWidth',2.1);
        plot(ax,time_min,pred_mean,'-','Color',colors(o,:),'LineWidth',3.3);
        text(ax,0.05,0.95,sprintf('%s\nSSE = %.4g',labels{o},summary_table.MedianCommonSSE(o)), ...
            'Units','normalized','VerticalAlignment','top','FontName','Arial', ...
            'FontSize',18,'FontWeight','bold','BackgroundColor','white','EdgeColor','none');
        xlabel(ax,'Time (min)','FontName','Arial','FontSize',24);
        ylabel(ax,'GFP fluorescence','FontName','Arial','FontSize',24);
        xlim(ax,[time_min(1),time_min(end)]);
        ymax=max([data_mean+data_sd,pred_mean+pred_sd],[],'omitnan');
        if isfinite(ymax)&&ymax>0, ylim(ax,[0 1.08*ymax]); end
        style_axis(ax,18);
    end
    data_axes=findall(fit_fig,'Type','axes');
    for k=1:numel(data_axes)
        pos=data_axes(k).Position; pos(2)=pos(2)+0.065; pos(4)=pos(4)-0.015; data_axes(k).Position=pos;
    end
    leg_ax=axes('Position',[0 0 1 1],'Visible','off'); hold(leg_ax,'on');
    h1=plot(leg_ax,NaN,NaN,'k--','LineWidth',2.1);
    h2=plot(leg_ax,NaN,NaN,'-','Color',colors(1,:),'LineWidth',3.3);
    h3=plot(leg_ax,NaN,NaN,'-','Color',colors(2,:),'LineWidth',3.3);
    h4=plot(leg_ax,NaN,NaN,'-','Color',colors(3,:),'LineWidth',3.3);
    L=legend(leg_ax,[h1 h2 h3 h4],{'Synthetic data mean','No Variance fit','Variance fit','Relative Variance fit'}, ...
        'NumColumns',4,'FontName','Arial','FontSize',18,'FontWeight','bold','Box','off');
    L.Units='normalized'; L.Position=[0.08 0.012 0.84 0.045];
    fit_stem=fullfile(output_dir,'STAR_Minimal3_FinalPlot');
    exportgraphics(fit_fig,[fit_stem,'.png'],'Resolution',300); savefig(fit_fig,[fit_stem,'.fig']);

    %% Four-panel fitted parameter distributions
    parameter_fig=figure('Position',[10,10,2000,900],'Color','w','Visible',settings.Visible);
    for p=1:4
        ax=subplot(2,2,p); hold(ax,'on');
        values=cell(1,3);
        for o=1:3
            v=parameter_groups{o}(:,p); values{o}=v(isfinite(v)&v>0);
        end
        matrix=pad_vectors(values);
        boxplot(ax,matrix,'Labels',{'No var.','Variance','Rel. var.'},'Symbol','o','Whisker',1.5,'OutlierSize',7);
        color_boxplot(ax,colors); color_outliers(ax,colors);
        set(ax,'YScale','log');
        title(ax,parameter_labels{p},'Interpreter','tex','FontName','Arial','FontSize',23,'FontWeight','bold');
        ylabel(ax,'Fitted value','FontName','Arial','FontSize',19);
        style_axis(ax,18);
    end
    parameter_stem=fullfile(output_dir,'ParDist_STAR_Minimal3');
    exportgraphics(parameter_fig,[parameter_stem,'.png'],'Resolution',300); savefig(parameter_fig,[parameter_stem,'.fig']);
    writetable(summary_table,fullfile(output_dir,'STAR_minimal3_synthetic_fit_summary.csv'));
    fprintf('Minimal STAR synthetic figures saved as %s.png and %s.png\n',fit_stem,parameter_stem);
end

function [time_min,data_mean,data_sd,pred_groups,param_groups,summary_table]=collect_data(records,objectives,criterion,synthetic_input)
    ids=unique([records.dataset_id]); assert(~isempty(ids),'No dataset IDs found.');
    template=select_record(records,ids(1),objectives{1},criterion); assert(~isempty(template),'No successful record found.');
    time_min=double(synthetic_input.Simu_t(:)');
    n_time=numel(time_min);
    n_rep=3;
    assert(size(synthetic_input.Simu_Traje,2)==n_time, ...
        'Simu_Traje columns must match Simu_t.');
    all_reps=nan(numel(ids)*n_rep,n_time); pred_groups=cell(1,3); param_groups=cell(1,3); sse_groups=cell(1,3);
    for o=1:3
        pred_groups{o}=nan(numel(ids),n_time); param_groups{o}=nan(numel(ids),4); sse_groups{o}=nan(numel(ids),1);
        for d=1:numel(ids)
            r=select_record(records,ids(d),objectives{o},criterion); if isempty(r), continue; end
            pred_groups{o}(d,:)=r.prediction(:)'; param_groups{o}(d,:)=r.p_opt(:)'; sse_groups{o}(d)=r.common_sse;
            if o==1
                output_rows=(d-1)*n_rep+(1:n_rep);
                input_rows=(ids(d)-1)*n_rep+(1:n_rep);
                all_reps(output_rows,:)=double(synthetic_input.Simu_Traje(input_rows,:));
            end
        end
    end
    data_mean=mean(all_reps,1,'omitnan'); data_sd=std(all_reps,0,1,'omitnan');
    summary_table=table(string(objectives(:)),cellfun(@(x)sum(isfinite(x)),sse_groups(:)), ...
        cellfun(@(x)median(x,'omitnan'),sse_groups(:)),cellfun(@(x)mean(x,'omitnan'),sse_groups(:)), ...
        cellfun(@(x)std(x,'omitnan'),sse_groups(:)), ...
        'VariableNames',{'Objective','SuccessfulDatasets','MedianCommonSSE','MeanCommonSSE','SDCommonSSE'});
end

function data=unpack_data_summary(data)
    % MAT-file structure fields can load as a 1x1 cell in some MATLAB
    % versions. Unwrap that representation before field access.
    while iscell(data)
        assert(numel(data)==1,'Expected one data-summary record per GA run.');
        data=data{1};
    end
    assert(isstruct(data) && isscalar(data), ...
        'Saved data_summary must be a scalar structure. Rerun the fitter if this error persists.');
end

function r=select_record(records,id,obj,criterion)
    candidates=records([records.dataset_id]==id&strcmp({records.objective_type},obj)&strcmp({records.status},'success'));
    if isempty(candidates), r=[]; return; end
    if strcmpi(criterion,'common_sse'), [~,k]=min([candidates.common_sse]);
    else, [~,k]=min([candidates.training_objective]); end
    r=candidates(k);
end

function M=pad_vectors(values)
    n=max(cellfun(@numel,values)); M=nan(n,numel(values));
    for i=1:numel(values), M(1:numel(values{i}),i)=values{i}(:); end
end

function color_boxplot(ax,colors)
    boxes=flipud(findobj(ax,'Tag','Box')); medians=flipud(findobj(ax,'Tag','Median')); whiskers=flipud(findobj(ax,'Tag','Whisker'));
    for i=1:min(numel(boxes),3)
        patch(ax,get(boxes(i),'XData'),get(boxes(i),'YData'),colors(i,:), ...
            'FaceAlpha',0.16,'EdgeColor','none','HandleVisibility','off');
        set(boxes(i),'Color',colors(i,:),'LineWidth',2);
    end
    for i=1:min(numel(medians),3), set(medians(i),'Color',colors(i,:),'LineWidth',2); end
    for i=1:min(numel(whiskers),6), set(whiskers(i),'Color',colors(ceil(i/2),:),'LineWidth',1.5); end
end

function color_outliers(ax,colors)
    h=flipud(findobj(ax,'Tag','Outliers'));
    for i=1:min(numel(h),3), set(h(i),'Marker','o','MarkerSize',7,'MarkerEdgeColor',colors(i,:), ...
            'MarkerFaceColor','none','LineWidth',1.25); end
end

function style_axis(ax,fs)
    grid(ax,'on'); box(ax,'on'); set(ax,'FontName','Arial','FontSize',fs,'LineWidth',0.9,'Layer','top');
    ax.XAxisLocation='bottom'; ax.YAxisLocation='left';
    try, ax.Toolbar.Visible='off'; catch, end
end

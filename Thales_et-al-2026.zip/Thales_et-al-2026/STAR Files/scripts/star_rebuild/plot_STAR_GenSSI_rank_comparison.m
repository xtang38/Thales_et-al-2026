function plot_STAR_GenSSI_rank_comparison(varargin)
%PLOT_STAR_GENSSI_RANK_COMPARISON Summarize STAR GenSSI results.
%
% Produces a manuscript-ready two-panel structural-identifiability summary.
% Panel A compares the stable GenSSI rank with the number of free parameters.
% Panel B displays the structural rank deficiency. The fixed input/output
% setting is mature GFP only, a single 8 nM STAR condition, PYtot = 0.5 nM,
% and zero initial molecular states.
%
% Verified GenSSI results:
%   Original mechanistic model: rank 5 / 8 parameters (deficiency 3)
%   Reduced effective model:    rank 5 / 6 parameters (deficiency 1)
%
% Example:
%   plot_STAR_GenSSI_rank_comparison('OutputDirectory', ...
%       fullfile(project_root,'results','STAR_model_comparison'));

    ip=inputParser;
    ip.addParameter('OutputDirectory','STAR_model_comparison',@(x)ischar(x)||isstring(x));
    ip.addParameter('Visible','on',@(x)any(strcmpi(x,{'on','off'})));
    ip.parse(varargin{:});
    settings=ip.Results;

    output_dir=char(settings.OutputDirectory);
    if ~isfolder(output_dir), mkdir(output_dir); end

    names={'Original 8P','Reduced 6P'};
    n_parameters=[8 6];
    stable_rank=[5 5];
    deficiency=n_parameters-stable_rank;
    colors=[0.25 0.25 0.25; 0.4940 0.1840 0.5560];

    fig=figure('Position',[10,10,1600,650],'Color','w','Visible',settings.Visible);

    ax1=subplot(1,2,1); hold(ax1,'on');
    b=bar(ax1,[n_parameters;stable_rank]','grouped','LineWidth',1.2);
    b(1).FaceColor=[0.75 0.75 0.75];
    b(2).FaceColor=[0.20 0.55 0.35];
    for k=1:2
        text(ax1,b(k).XEndPoints,b(k).YEndPoints+0.18,string(b(k).YData), ...
            'HorizontalAlignment','center','FontName','Arial','FontSize',22,'FontWeight','bold');
    end
    set(ax1,'XTick',1:2,'XTickLabel',names,'YLim',[0 9]);
    ylabel(ax1,'Number of dimensions','FontName','Arial','FontSize',25);
    legend(ax1,{'Free parameters','Stable GenSSI rank'},'Location','northwest', ...
        'FontName','Arial','FontSize',19,'FontWeight','bold','Box','off');
    style_axis(ax1,20);

    ax2=subplot(1,2,2); hold(ax2,'on');
    b2=bar(ax2,deficiency,'FaceColor','flat','LineWidth',1.2);
    b2.CData=colors;
    for k=1:2
        text(ax2,k,deficiency(k)+0.12,sprintf('%d',deficiency(k)), ...
            'HorizontalAlignment','center','FontName','Arial','FontSize',24,'FontWeight','bold');
    end
    set(ax2,'XTick',1:2,'XTickLabel',names,'YLim',[0 3.8]);
    ylabel(ax2,'Unresolved parameter directions','FontName','Arial','FontSize',25);
    style_axis(ax2,20);

    annotation(fig,'textbox',[0.22 0.015 0.56 0.045], ...
        'String','Mature GFP output only; single 8 nM STAR input; P_{Ytot}=0.5 nM', ...
        'HorizontalAlignment','center','EdgeColor','none','FontName','Arial', ...
        'FontSize',19,'FontWeight','bold');

    stem=fullfile(output_dir,'STAR_GenSSI_RankComparison');
    exportgraphics(fig,[stem,'.png'],'Resolution',300);
    savefig(fig,[stem,'.fig']);
    fprintf('GenSSI rank-comparison figure saved as %s.png\n',stem);
end

function style_axis(ax,fs)
    grid(ax,'on'); box(ax,'on'); set(ax,'FontSize',fs,'FontName','Arial', ...
        'LineWidth',0.9,'Layer','top');
    ax.XAxisLocation='bottom'; ax.YAxisLocation='left';
    try, ax.Toolbar.Visible='off'; catch, end
end

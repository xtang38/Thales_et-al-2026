function plot_STAR_original_vs_reduced6_shared_parameters(original_results_file,reduced_results_file,varargin)
%PLOT_STAR_ORIGINAL_VS_REDUCED6_SHARED_PARAMETERS Compare shared rates.
%
% Creates a four-panel comparison of the parameters common to both STAR
% formulations: beta_s, Ki, Ke, and alpha_gm. Within each panel, the first
% three boxplots are Original8 and the next three are Reduced6. Colors encode
% objective function (purple, teal, coral); lighter fills indicate Original8
% and darker fills indicate Reduced6. Only standard 1.5-IQR outliers appear.
%
% Example:
%   plot_STAR_original_vs_reduced6_shared_parameters(original_file,reduced_file, ...
%       'OutputDirectory',fullfile(project_root,'results','STAR_model_comparison'));

    ip=inputParser;
    ip.addRequired('original_results_file',@(x)ischar(x)||isstring(x));
    ip.addRequired('reduced_results_file',@(x)ischar(x)||isstring(x));
    ip.addParameter('OutputDirectory','',@(x)ischar(x)||isstring(x));
    ip.addParameter('SelectionCriterion','training_objective', ...
        @(x)any(strcmpi(x,{'training_objective','common_sse'})));
    ip.addParameter('Visible','on',@(x)any(strcmpi(x,{'on','off'})));
    ip.parse(original_results_file,reduced_results_file,varargin{:});
    settings=ip.Results;

    original=load(settings.original_results_file,'run_records','param_names');
    reduced=load(settings.reduced_results_file,'run_records','param_names');
    shared_names={'beta_s','K_i','K_e','alpha_gm'};
    labels={'\beta_s','K_i','K_e','\alpha_{gm}'};
    objectives={'no_variance','variance','relative_variance'};
    objective_colors=[0.4940 0.1840 0.5560; 0.3010 0.7450 0.9330; 0.8500 0.3250 0.0980];
    six_colors=[objective_colors;objective_colors];
    six_alpha=[0.10 0.10 0.10 0.35 0.35 0.35];

    if isempty(settings.OutputDirectory)
        [parent,~,~]=fileparts(settings.reduced_results_file);
        output_dir=fullfile(parent,'plots');
    else
        output_dir=char(settings.OutputDirectory);
    end
    if ~isfolder(output_dir), mkdir(output_dir); end

    fig=figure('Position',[10,10,1900,950],'Color','w','Visible',settings.Visible);
    for p=1:numel(shared_names)
        ax=subplot(2,2,p); hold(ax,'on');
        original_idx=find(strcmp(original.param_names,shared_names{p}),1);
        reduced_idx=find(strcmp(reduced.param_names,shared_names{p}),1);
        assert(~isempty(original_idx)&&~isempty(reduced_idx), ...
            'Shared parameter %s is missing from a result file.',shared_names{p});
        values=cell(1,6);
        for o=1:3
            po=selected_values(original.run_records,objectives{o},original_idx,settings.SelectionCriterion);
            pr=selected_values(reduced.run_records,objectives{o},reduced_idx,settings.SelectionCriterion);
            values{o}=po; values{o+3}=pr;
        end
        M=pad_vectors(values);
        boxplot(ax,M,'Labels',{'NV\newline8P','V\newline8P','RV\newline8P', ...
                                'NV\newline6P','V\newline6P','RV\newline6P'}, ...
            'Symbol','o','Whisker',1.5,'OutlierSize',7);
        fill_boxplots(ax,six_colors,six_alpha);
        color_outliers(ax,six_colors);
        set(ax,'YScale','log');
        title(ax,labels{p},'Interpreter','tex','FontName','Arial','FontSize',24,'FontWeight','bold');
        ylabel(ax,'Fitted value','FontName','Arial','FontSize',20);
        style_axis(ax,18);
    end

    % Minimal figure-level key without a legend box.
    key_axis=axes('Parent',fig,'Position',[0,0,1,1],'Visible','off'); hold(key_axis,'on');
    h1=patch(key_axis,NaN,NaN,objective_colors(1,:),'FaceAlpha',0.35,'EdgeColor',objective_colors(1,:));
    h2=patch(key_axis,NaN,NaN,objective_colors(2,:),'FaceAlpha',0.35,'EdgeColor',objective_colors(2,:));
    h3=patch(key_axis,NaN,NaN,objective_colors(3,:),'FaceAlpha',0.35,'EdgeColor',objective_colors(3,:));
    h4=plot(key_axis,NaN,NaN,'k-','LineWidth',0.1);
    L=legend(key_axis,[h1 h2 h3 h4],{'No Variance','Variance','Relative Variance','8P = original; 6P = reduced'}, ...
        'NumColumns',4,'FontName','Arial','FontSize',17,'FontWeight','bold','Box','off');
    L.Units='normalized'; L.Position=[0.12 0.015 0.76 0.045];

    stem=fullfile(output_dir,'STAR_Original8_vs_Reduced6_SharedParameters');
    exportgraphics(fig,[stem,'.png'],'Resolution',300);
    savefig(fig,[stem,'.fig']);
    fprintf('Shared-parameter comparison saved as %s.png\n',stem);
end

function values=selected_values(records,objective,pidx,criterion)
    ids=unique([records.dataset_id]); values=nan(numel(ids),1);
    for j=1:numel(ids)
        idx=[records.dataset_id]==ids(j) & strcmp({records.objective_type},objective) & ...
            strcmp({records.status},'success');
        c=records(idx); if isempty(c), continue; end
        if strcmpi(criterion,'training_objective'), [~,k]=min([c.training_objective]);
        else, [~,k]=min([c.common_sse]); end
        values(j)=c(k).p_opt(pidx);
    end
    values=values(isfinite(values)&values>0);
end

function M=pad_vectors(values)
    n=max(cellfun(@numel,values)); M=nan(n,numel(values));
    for i=1:numel(values), M(1:numel(values{i}),i)=values{i}(:); end
end

function fill_boxplots(ax,colors,alphas)
    boxes=flipud(findobj(ax,'Tag','Box'));
    medians=flipud(findobj(ax,'Tag','Median'));
    whiskers=flipud(findobj(ax,'Tag','Whisker'));
    for i=1:min(numel(boxes),size(colors,1))
        patch(ax,get(boxes(i),'XData'),get(boxes(i),'YData'),colors(i,:), ...
            'FaceAlpha',alphas(i),'EdgeColor','none','HandleVisibility','off');
        set(boxes(i),'Color',colors(i,:),'LineWidth',2);
    end
    for i=1:min(numel(medians),size(colors,1)), set(medians(i),'Color',colors(i,:),'LineWidth',2); end
    for i=1:min(numel(whiskers),2*size(colors,1)), set(whiskers(i),'Color',colors(ceil(i/2),:),'LineWidth',1.4); end
end

function color_outliers(ax,colors)
    h=flipud(findobj(ax,'Tag','Outliers'));
    for i=1:min(numel(h),size(colors,1))
        set(h(i),'Marker','o','MarkerSize',7,'MarkerEdgeColor',colors(i,:), ...
            'MarkerFaceColor','none','LineWidth',1.25);
    end
end

function style_axis(ax,fs)
    grid(ax,'on'); box(ax,'on'); set(ax,'FontSize',fs,'FontName','Arial','LineWidth',0.9,'Layer','top');
    ax.XAxisLocation='bottom'; ax.YAxisLocation='left';
    try, ax.Toolbar.Visible='off'; catch, end
end

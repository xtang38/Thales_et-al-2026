function dx = STAR_Reduced6_GenAlg_Model(~, x, p)
%STAR_REDUCED6_GENALG_MODEL Six-parameter time-scale-reduced STAR model.
%
% Parameter vector:
%   p(1) = alpha_tx   common effective transcription rate
%   p(2) = delta_rna  common effective RNA-loss rate
%   p(3) = beta_s     STAR-target interaction rate
%   p(4) = Ki         initiation/maturation rate
%   p(5) = Ke         elongation/intermediate-conversion rate
%   p(6) = alpha_gm   GFP maturation/measurement rate
%
% This deliberate coarse-grained model imposes:
%   alpha_s = alpha_m = alpha_tx
%   delta_s = delta_m = delta_rna
%
% The equalities represent effective long-time parameters for the four-hour
% GFP experiment; they do not assert that the underlying molecular templates
% or decay mechanisms are identical. The known plasmid inputs remain:
%   global par.Ps    STAR plasmid concentration (M)
%   global par.PYtot target plasmid concentration (M)

    global par

    S  = x(1);  % STAR RNA
    Y  = x(2);  % target mRNA
    Yi = x(3);  % intermediate target RNA state
    G  = x(4);  % immature GFP

    Py = par.PYtot;

    alpha_tx  = p(1);
    delta_rna = p(2);
    beta_s    = p(3);
    Ki        = p(4);
    Ke        = p(5);
    alpha_gm  = p(6);

    dx = zeros(5,1);
    dx(1) = alpha_tx * par.Ps - delta_rna * S - beta_s * S * Py;
    dx(2) = alpha_tx * beta_s * S * Py - delta_rna * Y - Ki * Y + Ke * Yi;
    dx(3) = Ki * Y - Ke * Yi;
    dx(4) = Ke * Yi - alpha_gm * G;
    dx(5) = alpha_gm * G;  % mature GFP observable
end

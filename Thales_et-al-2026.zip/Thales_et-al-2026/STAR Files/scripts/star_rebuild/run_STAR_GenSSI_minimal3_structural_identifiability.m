function run_STAR_GenSSI_minimal3_structural_identifiability(genssi_root, varargin)
%RUN_STAR_GENSSI_MINIMAL3_STRUCTURAL_IDENTIFIABILITY Analyze minimal STAR.
%
% Runs GenSSI for the confirmed three-state effective STAR model with four
% unknown effective rates: theta_tx, beta, delta_RNA, and delta_G.
%
% The analysis assumes the fixed 8 nM STAR condition, known Py = 0.5 nM,
% zero initial states, and mature GFP as the sole output. It is analytical:
% it does not use fitted parameter values, replicate variance, objective
% function selection, or genetic-algorithm results.
%
% Example:
%   run_STAR_GenSSI_minimal3_structural_identifiability(genssi_root, ...
%       'Nder',12,'StoreResults',true);

    ip = inputParser;
    ip.addRequired('genssi_root', @(x) ischar(x) || isstring(x));
    ip.addParameter('Nder',12,@(x)isnumeric(x)&&isscalar(x)&&x>=1);
    ip.addParameter('StoreResults',true,@(x)islogical(x)&&isscalar(x));
    ip.parse(genssi_root,varargin{:});
    settings = ip.Results;

    genssi_root = char(settings.genssi_root);
    assert(isfolder(genssi_root),'GenSSI folder not found: %s',genssi_root);
    assert(isfile(fullfile(genssi_root,'genssiStartup.m')), ...
        'The supplied folder is not a GenSSI installation: %s',genssi_root);

    this_folder = fileparts(mfilename('fullpath'));
    addpath(this_folder);
    addpath(genssi_root);
    genssiStartup;

    options = struct('verbose',true,'store',settings.StoreResults, ...
        'closeFigure',false,'reportCompTime',true,'noRank',false);

    % Explicit parameter-vector argument avoids the empty-parameter-list
    % issue encountered with this GenSSI version.
    minimal_model = STAR_Minimal3_GenSSI();

    fprintf('\n=== GenSSI: minimal three-state, four-parameter STAR model ===\n');
    genssiMain('STAR_Minimal3_GenSSI',settings.Nder,minimal_model.sym.p,options);
    fprintf('\nMinimal STAR GenSSI analysis completed. Inspect model_information.txt and the tableau.\n');
end

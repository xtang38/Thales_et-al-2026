function run_STAR_GenSSI_reduced6_structural_identifiability(genssi_root, varargin)
%RUN_STAR_GENSSI_REDUCED6_STRUCTURAL_IDENTIFIABILITY Analyze reduced STAR.
%
% Runs GenSSI for the six-parameter time-scale-reduced STAR model:
%   alpha_s = alpha_m = alpha_tx
%   delta_s = delta_m = delta_rna
%
% The analysis uses the 8 nM STAR condition, known target plasmid
% Py = 0.5 nM, zero initial conditions, and mature GFP as the only output.
% It is analytical: it does not depend on fitted values, variance weights,
% synthetic datasets, or genetic-algorithm results.
%
% Example:
%   run_STAR_GenSSI_reduced6_structural_identifiability(genssi_root, ...
%       'Nder', 16, 'StoreResults', true);

    ip = inputParser;
    ip.addRequired('genssi_root', @(x) ischar(x) || isstring(x));
    ip.addParameter('Nder', 16, @(x) isnumeric(x) && isscalar(x) && x >= 1);
    ip.addParameter('StoreResults', true, @(x) islogical(x) && isscalar(x));
    ip.parse(genssi_root, varargin{:});
    settings = ip.Results;

    genssi_root = char(settings.genssi_root);
    assert(isfolder(genssi_root), 'GenSSI folder not found: %s', genssi_root);
    assert(isfile(fullfile(genssi_root,'genssiStartup.m')), ...
        'The supplied folder is not a GenSSI installation: %s', genssi_root);

    this_folder = fileparts(mfilename('fullpath'));
    addpath(this_folder);
    addpath(genssi_root);
    genssiStartup;

    options = struct('verbose',true,'store',settings.StoreResults, ...
        'closeFigure',false,'reportCompTime',true,'noRank',false);

    % Pass the parameter vector explicitly for compatibility with GenSSI 2.0.
    reduced_model = STAR_GenSSI_Reduced6();

    fprintf('\n=== GenSSI: six-parameter time-scale-reduced STAR model ===\n');
    genssiMain('STAR_GenSSI_Reduced6', settings.Nder, ...
        reduced_model.sym.p, options);
    fprintf('\nReduced STAR GenSSI analysis completed. Inspect the GenSSI report and tableau.\n');
end

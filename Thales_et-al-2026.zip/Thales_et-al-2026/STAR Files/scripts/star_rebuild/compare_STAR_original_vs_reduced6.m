function comparison = compare_STAR_original_vs_reduced6(original_results_file,reduced_results_file,varargin)
%COMPARE_STAR_ORIGINAL_VS_REDUCED6 Compare practical stability fairly.
%
% Compares original eight-parameter and reduced six-parameter synthetic
% calibration results. It reports common-SSE trade-off, log10-IQR parameter
% spread, and proximity to search bounds. For shared parameters beta_s, Ki,
% Ke, and alpha_gm, it supplies a direct original-versus-reduced comparison.
%
% Example:
%   compare_STAR_original_vs_reduced6(original_file,reduced_file, ...
%       'OutputDirectory',fullfile(project_root,'results','STAR_model_comparison'));

    ip=inputParser;
    ip.addRequired('original_results_file',@(x)ischar(x)||isstring(x));
    ip.addRequired('reduced_results_file',@(x)ischar(x)||isstring(x));
    ip.addParameter('OutputDirectory','',@(x)ischar(x)||isstring(x));
    ip.addParameter('SelectionCriterion','training_objective', ...
        @(x)any(strcmpi(x,{'training_objective','common_sse'})));
    ip.addParameter('BoundFraction',0.02,@(x)isnumeric(x)&&isscalar(x)&&x>0&&x<0.5);
    ip.parse(original_results_file,reduced_results_file,varargin{:});
    settings=ip.Results;

    original=load(settings.original_results_file,'run_records','lb','ub','param_names');
    reduced=load(settings.reduced_results_file,'run_records','lb','ub','param_names');
    assert(numel(original.param_names)==8,'Original file must contain eight parameters.');
    assert(numel(reduced.param_names)==6,'Reduced file must contain six parameters.');

    objectives={'no_variance','variance','relative_variance'};
    model_names={'Original8','Reduced6'};
    sources={original,reduced};
    all_rows=table();
    shared_rows=table();

    for m=1:2
        src=sources{m};
        for o=1:3
            [P,SSE]=selected_parameters(src.run_records,objectives{o},settings.SelectionCriterion);
            for p=1:numel(src.param_names)
                vals=P(:,p); vals=vals(isfinite(vals)&vals>0);
                log_iqr=iqr(log10(vals));
                lo=src.lb(p); hi=src.ub(p);
                logpos=(log10(vals)-log10(lo))./(log10(hi)-log10(lo));
                bound_rate=mean(logpos<=settings.BoundFraction | logpos>=1-settings.BoundFraction);
                newrow=table(string(model_names{m}),string(objectives{o}),string(src.param_names{p}), ...
                    numel(vals),median(vals),iqr(vals),log_iqr,bound_rate,median(SSE,'omitnan'), ...
                    'VariableNames',{'Model','Objective','Parameter','SuccessfulDatasets', ...
                    'MedianValue','LinearIQR','Log10IQR','BoundProximityRate','MedianCommonSSE'});
                all_rows=[all_rows;newrow]; %#ok<AGROW>
            end
        end
    end

    shared_names={'beta_s','K_i','K_e','alpha_gm'};
    for o=1:3
        [P1,~]=selected_parameters(original.run_records,objectives{o},settings.SelectionCriterion);
        [P2,~]=selected_parameters(reduced.run_records,objectives{o},settings.SelectionCriterion);
        for k=1:numel(shared_names)
            i1=find(strcmp(original.param_names,shared_names{k}),1);
            i2=find(strcmp(reduced.param_names,shared_names{k}),1);
            v1=P1(:,i1); v2=P2(:,i2);
            v1=v1(isfinite(v1)&v1>0); v2=v2(isfinite(v2)&v2>0);
            row=table(string(objectives{o}),string(shared_names{k}), ...
                iqr(log10(v1)),iqr(log10(v2)),iqr(log10(v1))-iqr(log10(v2)), ...
                'VariableNames',{'Objective','SharedParameter','OriginalLog10IQR', ...
                'ReducedLog10IQR','SpreadReductionLog10IQR'});
            shared_rows=[shared_rows;row]; %#ok<AGROW>
        end
    end

    if isempty(settings.OutputDirectory)
        [parent,~,~]=fileparts(settings.reduced_results_file);
        output_dir=fullfile(parent,'model_comparison');
    else
        output_dir=char(settings.OutputDirectory);
    end
    if ~isfolder(output_dir), mkdir(output_dir); end
    writetable(all_rows,fullfile(output_dir,'STAR_original_vs_reduced6_parameter_stability.csv'));
    writetable(shared_rows,fullfile(output_dir,'STAR_original_vs_reduced6_shared_parameter_comparison.csv'));

    comparison=struct('all_parameter_metrics',all_rows,'shared_parameter_metrics',shared_rows, ...
        'selection_criterion',settings.SelectionCriterion,'bound_fraction',settings.BoundFraction);
    save(fullfile(output_dir,'STAR_original_vs_reduced6_comparison.mat'),'comparison');
    fprintf('Model-stability comparison saved in: %s\n',output_dir);
end

function [P,SSE]=selected_parameters(records,objective,criterion)
    ids=unique([records.dataset_id]);
    first=find(strcmp({records.objective_type},objective) & strcmp({records.status},'success'),1);
    assert(~isempty(first),'No successful records for objective %s.',objective);
    npar=numel(records(first).p_opt);
    P=nan(numel(ids),npar); SSE=nan(numel(ids),1);
    for j=1:numel(ids)
        idx=[records.dataset_id]==ids(j) & strcmp({records.objective_type},objective) & strcmp({records.status},'success');
        c=records(idx); if isempty(c), continue; end
        if strcmpi(criterion,'training_objective'), [~,q]=min([c.training_objective]);
        else, [~,q]=min([c.common_sse]); end
        P(j,:)=c(q).p_opt(:)'; SSE(j)=c(q).common_sse;
    end
end

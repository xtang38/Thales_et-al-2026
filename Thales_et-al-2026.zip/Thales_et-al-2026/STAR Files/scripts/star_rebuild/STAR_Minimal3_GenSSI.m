function model = STAR_Minimal3_GenSSI()
%STAR_MINIMAL3_GENSSI Structural-identifiability model for minimal STAR.
%
% Three-state, four-parameter effective model for long-duration STAR GFP
% measurements. It retains effective transcription, STAR-target binding,
% common RNA loss, and GFP loss while omitting the intermediate/maturation
% states from the original five-state formulation.
%
% Dynamic states
%   Z : effective STAR-expression state
%   A : effective activated-target / GFP-production state
%   G : mature GFP (the sole measured output)
%
% Unknown effective parameters
%   theta_tx : effective STAR transcription/output gain
%   beta     : STAR-target binding/activation rate
%   delta_RNA: common RNA loss rate
%   delta_G  : GFP loss/degradation rate
%
% Known constants
%   Ps = 8 nM   : STAR plasmid concentration
%   Py = 0.5 nM : target plasmid concentration
%
% Equations
%   dZ/dt = theta_tx*Ps - (beta*Py + delta_RNA)*Z
%   dA/dt = beta*Py*Z - delta_RNA*A
%   dG/dt = A - delta_G*G
%
% The known 1e6 fluorescence scaling is omitted because a known output
% multiplier does not alter structural identifiability.

    % States
    syms Z A G

    % Unknown effective kinetic parameters
    % beta is a MATLAB built-in function name; use beta_bind internally.
    syms theta_tx beta_bind delta_RNA delta_G

    % Known experimental inputs in molar units.
    Ps = sym(8e-9);
    Py = sym(0.5e-9);

    % Unknowns tested by GenSSI.
    model.sym.p = [theta_tx; beta_bind; delta_RNA; delta_G];

    % States and no free continuous controls for one fixed condition.
    model.sym.x = [Z; A; G];
    model.sym.g = [];

    % Autonomous effective dynamics.
    model.sym.xdot = [ ...
        theta_tx*Ps - (beta_bind*Py + delta_RNA)*Z; ...
        beta_bind*Py*Z - delta_RNA*A; ...
        A - delta_G*G];

    % Same known initial condition convention as previous analyses.
    model.sym.x0 = [0; 0; 0];

    % Mature GFP is the only observable.
    model.sym.y = [G];
end

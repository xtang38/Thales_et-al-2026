function plot_STAR_minimal3_four_condition_GA_results(results_file,varargin)
%PLOT_STAR_MINIMAL3_FOUR_CONDITION_GA_RESULTS Plot minimal STAR experiment.
%
% Creates only the requested three-panel experimental fitting figure for the
% four-parameter minimal STAR model. Each panel is one objective function.
% Dashed curves are the nine-replicate condition means; shaded bands are
% mean +/- 1 sample SD; solid curves are the selected ODE fit.

    ip=inputParser;
    ip.addRequired('results_file',@(x)ischar(x)||isstring(x));
    ip.addParameter('OutputDirectory','',@(x)ischar(x)||isstring(x));
    ip.addParameter('SelectionCriterion','training_objective', ...
        @(x)any(strcmpi(x,{'common_sse','training_objective'})));
    ip.addParameter('Visible','on',@(x)any(strcmpi(x,{'on','off'})));
    ip.parse(results_file,varargin{:}); settings=ip.Results;

    source=load(settings.results_file,'run_records','conditions');
    assert(isfield(source,'run_records')&&~isempty(source.run_records), ...
        'No minimal-model experimental fitting records found in %s.',settings.results_file);
    assert(isfield(source,'conditions')&&numel(source.conditions)==4, ...
        'Results must contain the four experimental STAR conditions.');
    if isempty(settings.OutputDirectory)
        [parent,~,~]=fileparts(settings.results_file); output_dir=fullfile(parent,'plots');
    else
        output_dir=char(settings.OutputDirectory);
    end
    if ~isfolder(output_dir), mkdir(output_dir); end

    objectives={'no_variance','variance','relative_variance'};
    labels={'No Variance','Variance','Relative Variance'};
    condition_colors=lines(numel(source.conditions));
    fig=figure('Position',[10,10,2000,720],'Color','w','Visible',settings.Visible);
    for o=1:3
        ax=subplot(1,3,o); hold(ax,'on');
        best=select_record(source.run_records,objectives{o},settings.SelectionCriterion);
        if isempty(best)
            text(ax,0.5,0.5,'No successful GA result','Units','normalized', ...
                'HorizontalAlignment','center','FontName','Arial','FontSize',16);
            style_axis(ax); continue;
        end
        all_time=[]; y_upper=0;
        for c=1:numel(source.conditions)
            condition=source.conditions(c); t=condition.time_min(:)';
            y=condition.mean_data(:)'; sd=condition.sample_sd(:)'; pred=best.predictions(c,:);
            color=condition_colors(c,:);
            fill(ax,[t fliplr(t)],[y-sd fliplr(y+sd)],color, ...
                'FaceAlpha',0.20,'EdgeColor','none','HandleVisibility','off');
            plot(ax,t,y,'--','Color',color,'LineWidth',1.8);
            plot(ax,t,pred,'-','Color',color,'LineWidth',3.0);
            all_time=[all_time t]; %#ok<AGROW>
            y_upper=max([y_upper,y+sd,pred],[],'omitnan');
        end
        text(ax,0.05,0.95,sprintf('Experimental data - %s\nSSE = %.4f', ...
            labels{o},best.common_sse),'Units','normalized','VerticalAlignment','top', ...
            'HorizontalAlignment','left','FontName','Arial','FontSize',16,'FontWeight','bold', ...
            'BackgroundColor','white','EdgeColor','none');
        xlabel(ax,'Time (min)','FontName','Arial','FontSize',20);
        ylabel(ax,'GFP fluorescence','FontName','Arial','FontSize',20);
        xlim(ax,[min(all_time) max(all_time)]);
        if isfinite(y_upper)&&y_upper>0, ylim(ax,[0 1.08*y_upper]); end
        style_axis(ax);
    end

    legend_axis=axes('Position',[0 0 1 1],'Visible','off'); hold(legend_axis,'on');
    h_exp=gobjects(1,numel(source.conditions)); h_sim=gobjects(1,numel(source.conditions));
    labels_exp=cell(1,numel(source.conditions)); labels_sim=cell(1,numel(source.conditions));
    for c=1:numel(source.conditions)
        color=condition_colors(c,:); name=source.conditions(c).display_name;
        h_exp(c)=plot(legend_axis,NaN,NaN,'--','Color',color,'LineWidth',1.8);
        h_sim(c)=plot(legend_axis,NaN,NaN,'-','Color',color,'LineWidth',3.0);
        labels_exp{c}=[name,' (Exp)']; labels_sim{c}=[name,' (Sim)'];
    end
    L=legend(legend_axis,[h_exp h_sim],[labels_exp labels_sim], ...
        'NumColumns',8,'Location','southoutside','FontSize',16,'FontName','Arial','FontWeight','bold','Box','off');
    L.Units='normalized'; L.Position=[0.02 0.006 0.96 0.05];

    output_stem=fullfile(output_dir,'STAR_Minimal3_Experimental_FinalPlot');
    exportgraphics(fig,[output_stem,'.png'],'Resolution',300); savefig(fig,[output_stem,'.fig']);
    fprintf('Minimal STAR experimental figure saved as %s.png and %s.fig\n',output_stem,output_stem);
end

function record=select_record(records,objective_type,criterion)
    candidates=records(strcmp({records.objective_type},objective_type)&strcmp({records.status},'success'));
    if isempty(candidates), record=[]; return; end
    if strcmpi(criterion,'common_sse'), [~,k]=min([candidates.common_sse]);
    else, [~,k]=min([candidates.training_objective]); end
    record=candidates(k);
end

function style_axis(ax)
    grid(ax,'on'); box(ax,'on'); set(ax,'FontSize',15,'FontName','Arial','LineWidth',1.0,'Layer','top');
    ax.XAxisLocation='bottom'; ax.YAxisLocation='left';
    try, ax.Toolbar.Visible='off'; catch, end
end

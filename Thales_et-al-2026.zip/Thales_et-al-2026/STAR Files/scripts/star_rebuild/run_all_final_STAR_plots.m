function run_all_final_STAR_plots(project_root)
%RUN_ALL_FINAL_STAR_PLOTS Regenerate only the requested STAR paper figures.
%
% This function does NOT run genetic algorithms and does NOT generate any
% rank or cross-model-comparison figures. It regenerates only:
%   1. Original 8-parameter synthetic fit and parameter-distribution plots
%   2. Reduced 6-parameter synthetic fit and parameter-distribution plots
%   3. Four-condition experimental STAR fitting plot
%
% Expected project layout:
%   project_root/
%       star_rebuild/  (this file and the three plotting routines)
%       results/
%           STAR_synthetic_three_objective/
%           STAR_reduced6_synthetic/
%           STAR_experimental_four_condition/
%
% Example:
%   run_all_final_STAR_plots(project_root)

    arguments
        project_root (1,:) char
    end

    star_rebuild_dir = fullfile(project_root,'star_rebuild');
    addpath(star_rebuild_dir);

    original_file = fullfile(project_root,'results', ...
        'STAR_synthetic_three_objective','STAR_synthetic_three_objective_results.mat');
    reduced_file = fullfile(project_root,'results', ...
        'STAR_reduced6_synthetic','STAR_reduced6_synthetic_results.mat');
    experimental_file = fullfile(project_root,'results', ...
        'STAR_experimental_four_condition','STAR_experimental_four_condition_results.mat');

    assert(isfile(original_file), ...
        'Original synthetic results were not found: %s',original_file);
    assert(isfile(reduced_file), ...
        'Reduced-6 synthetic results were not found: %s',reduced_file);
    assert(isfile(experimental_file), ...
        'Experimental four-condition results were not found: %s',experimental_file);

    criterion = 'training_objective';
    fprintf('\n=== REGENERATING REQUESTED STAR PAPER FIGURES ===\n');

    fprintf('1/3 Original 8-parameter synthetic figures...\n');
    plot_STAR_synthetic_GA_results(original_file, ...
        'SelectionCriterion',criterion, ...
        'OutputDirectory',fullfile(fileparts(original_file),'plots'));

    fprintf('2/3 Reduced 6-parameter synthetic figures...\n');
    plot_STAR_reduced6_synthetic_GA_results(reduced_file, ...
        'SelectionCriterion',criterion, ...
        'OutputDirectory',fullfile(fileparts(reduced_file),'plots'));

    fprintf('3/3 Four-condition experimental STAR figure...\n');
    plot_STAR_four_condition_GA_results(experimental_file, ...
        'SelectionCriterion',criterion, ...
        'OutputDirectory',fullfile(fileparts(experimental_file),'plots'));

    fprintf('\nFinished. Requested figure folders:\n');
    fprintf('  %s\n',fullfile(fileparts(original_file),'plots'));
    fprintf('  %s\n',fullfile(fileparts(reduced_file),'plots'));
    fprintf('  %s\n',fullfile(fileparts(experimental_file),'plots'));
end

function model = STAR_GenSSI_Reduced6()
%STAR_GENSSI_REDUCED6 Structural-identifiability model for reduced STAR.
%
% Six-parameter time-scale-reduced model for the four-hour GFP experiment.
% The model imposes alpha_s = alpha_m = alpha_tx and
% delta_s = delta_m = delta_rna. It analyzes the 8 nM STAR-plasmid condition,
% known 0.5 nM target plasmid, zero state initial conditions, and mature GFP
% as the only observable.

    % State variables
    syms S Y Yi G Gm

    % Unknown effective kinetic parameters
    syms alpha_tx delta_rna beta_s Ki Ke alpha_gm

    % Known inputs in molar units
    Ps = sym(8e-9);
    Py = sym(0.5e-9);

    % Six parameters considered by GenSSI
    model.sym.p = [alpha_tx; delta_rna; beta_s; Ki; Ke; alpha_gm];

    % Dynamic states and no continuous controls
    model.sym.x = [S; Y; Yi; G; Gm];
    model.sym.g = [];

    % Reduced dynamics matching STAR_Reduced6_GenAlg_Model.m
    model.sym.xdot = [ ...
        alpha_tx*Ps - delta_rna*S - beta_s*S*Py; ...
        alpha_tx*beta_s*S*Py - delta_rna*Y - Ki*Y + Ke*Yi; ...
        Ki*Y - Ke*Yi; ...
        Ke*Yi - alpha_gm*G; ...
        alpha_gm*G];

    % Same known initial conditions and observable as the original analysis
    model.sym.x0 = [0; 0; 0; 0; 0];
    model.sym.y = [Gm];
end

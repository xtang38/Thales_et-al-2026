function plot_STAR_synthetic_GA_results(results_file,varargin)
%PLOT_STAR_SYNTHETIC_GA_RESULTS Plot STAR synthetic fits and parameters.
%
% The fitting figure distinguishes two different sources of variation:
%   1. The pale blue band is the observed spread of ALL synthetic replicate
%      measurements across all selected datasets (mean +/- 1 SD).
%   2. The colored band is the spread of the fitted GFP trajectories across
%      datasets for that objective (mean +/- 1 SD).
%
% Therefore, a wider green/teal band in the Variance panel indicates that
% inverse-variance weighting produced more variable FITTED trajectories. It
% is not a direct plot of the variance_Data.xlsx values. The workbook is used
% in run_STAR_synthetic_three_objective_ga.m to construct the weights.
%
% The script works with an already completed fitting result; rerunning the
% genetic algorithms is NOT required after this plotting update.
%
% Example:
%   plot_STAR_synthetic_GA_results( ...
%       'STAR_synthetic_three_objective/STAR_synthetic_three_objective_results.mat', ...
%       'OutputDirectory','STAR_synthetic_three_objective/plots');

    ip = inputParser;
    ip.addRequired('results_file',@(x)ischar(x)||isstring(x));
    ip.addParameter('OutputDirectory','',@(x)ischar(x)||isstring(x));
    ip.addParameter('SelectionCriterion','training_objective', ...
        @(x)any(strcmpi(x,{'common_sse','training_objective'})));
    ip.addParameter('ReferenceParameters',[], ...
        @(x)isempty(x)||(isnumeric(x)&&isvector(x)&&numel(x)==8));
    ip.addParameter('FitFigureTitle','STAR: Synthetic Benchmark Across 3 Optimization Sets', ...
        @(x)ischar(x)||isstring(x));
    ip.addParameter('Visible','on',@(x)any(strcmpi(x,{'on','off'})));
    ip.addParameter('SavePDF',false,@(x)islogical(x)&&isscalar(x));
    ip.parse(results_file,varargin{:});
    settings = ip.Results;

    source = load(settings.results_file,'run_records','param_names');
    assert(isfield(source,'run_records') && ~isempty(source.run_records), ...
        'No synthetic STAR fitting records were found in %s.',settings.results_file);

    if isempty(settings.OutputDirectory)
        [parent_dir,~,~] = fileparts(settings.results_file);
        output_dir = fullfile(parent_dir,'plots');
    else
        output_dir = char(settings.OutputDirectory);
    end
    if ~isfolder(output_dir), mkdir(output_dir); end

    objectives = {'no_variance','variance','relative_variance'};
    objective_labels = {'No Variance','Variance','Relative Variance'};
    % Match the objective-color convention used in the manuscript figures.
    objective_colors = [0.4940 0.1840 0.5560;  ... % purple: No Variance
                        0.3010 0.7450 0.9330;  ... % teal: Variance
                        0.8500 0.3250 0.0980];     % coral: Relative Variance
    % Synthetic-data mean is deliberately black for maximum contrast.
    data_color = [0.0000 0.0000 0.0000];
    data_band_color = [0.5500 0.7200 0.8500];
    parameter_labels = {'\alpha_s','\delta_s','\delta_m','\beta_s', ...
                        '\alpha_m','K_i','K_e','\alpha_{gm}'};

    [time_min,data_mean,data_sd,prediction_groups,parameter_groups,summary_table] = ...
        collect_synthetic_plot_data(source.run_records,objectives,settings.SelectionCriterion);

    %% Three-panel synthetic trajectory figure
    fit_fig = figure('Position',[10,10,2000,720],'Color','w','Visible',settings.Visible);
    for objective_index = 1:numel(objectives)
        ax = subplot(1,3,objective_index);
        hold(ax,'on');

        prediction_matrix = prediction_groups{objective_index};
        simulated_mean = mean(prediction_matrix,1,'omitnan');
        simulated_sd = std(prediction_matrix,0,1,'omitnan');
        objective_color = objective_colors(objective_index,:);
        time_fill = [time_min,fliplr(time_min)];

        % Data variation: all 3 x N synthetic replicate trajectories.
        fill(ax,time_fill,[data_mean-data_sd,fliplr(data_mean+data_sd)], ...
            data_band_color,'FaceAlpha',0.30,'EdgeColor','none', ...
            'HandleVisibility','off');

        % Objective-specific fitted-trajectory variation: one selected fit per
        % dataset. This is the band that becomes wide when an objective yields
        % unstable parameter/trajectory recovery.
        fill(ax,time_fill,[simulated_mean-simulated_sd,fliplr(simulated_mean+simulated_sd)], ...
            objective_color,'FaceAlpha',0.40,'EdgeColor','none', ...
            'HandleVisibility','off');

        plot(ax,time_min,data_mean,'--','Color',data_color,'LineWidth',2.1, ...
            'DisplayName','Synthetic data mean');
        plot(ax,time_min,simulated_mean,'-','Color',objective_color,'LineWidth',3.3, ...
            'DisplayName',[objective_labels{objective_index},' fit']);

        panel_sse = summary_table.MedianCommonSSE(objective_index);
        text(ax,0.05,0.95,sprintf('Synthetic data - %s\nSSE = %.4g', ...
            objective_labels{objective_index},panel_sse), ...
            'Units','normalized','VerticalAlignment','top','HorizontalAlignment','left', ...
            'FontName','Arial','FontSize',18,'FontWeight','bold', ...
            'BackgroundColor','white','EdgeColor','none');
        xlabel(ax,'Time (min)','FontName','Arial','FontSize',24);
        ylabel(ax,'GFP fluorescence','FontName','Arial','FontSize',24);
        xlim(ax,[time_min(1),time_min(end)]);
        ymax = max([data_mean+data_sd,simulated_mean+simulated_sd],[],'omitnan');
        if isfinite(ymax) && ymax>0, ylim(ax,[0,1.08*ymax]); end
        style_axis(ax,18);
    end

    % Move the three data axes upward to reserve space for the enlarged
    % figure-level legend below the x-axis labels.
    fit_axes = findall(fit_fig,'Type','axes');
    for ax_index = 1:numel(fit_axes)
        pos = fit_axes(ax_index).Position;
        pos(2) = pos(2) + 0.065;
        pos(4) = pos(4) - 0.015;
        fit_axes(ax_index).Position = pos;
    end

    % Figure-level legend keeps the same compact style used in the second part.
    legend_axis = axes('Position',[0,0,1,1],'Visible','off');
    hold(legend_axis,'on');
    h_data = plot(legend_axis,NaN,NaN,'--','Color',data_color,'LineWidth',2.1);
    h_no_var = plot(legend_axis,NaN,NaN,'-','Color',objective_colors(1,:),'LineWidth',3.3);
    h_var = plot(legend_axis,NaN,NaN,'-','Color',objective_colors(2,:),'LineWidth',3.3);
    h_rel_var = plot(legend_axis,NaN,NaN,'-','Color',objective_colors(3,:),'LineWidth',3.3);
    legend_handle = legend(legend_axis,[h_data,h_no_var,h_var,h_rel_var], ...
        {'Synthetic data mean','No Variance fit','Variance fit','Relative Variance fit'}, ...
        'NumColumns',4,'FontSize',18,'FontName','Arial', ...
        'FontWeight','bold','Box','off');
    legend_handle.Units = 'normalized';
    legend_handle.Position = [0.08,0.012,0.84,0.045];

    fit_stem = fullfile(output_dir,'STAR_FinalPlot');
    exportgraphics(fit_fig,[fit_stem,'.png'],'Resolution',300);
    savefig(fit_fig,[fit_stem,'.fig']);
    if settings.SavePDF, exportgraphics(fit_fig,[fit_stem,'.pdf'],'ContentType','vector'); end

    %% Eight-panel fitted-parameter distribution figure
    parameter_fig = figure('Position',[10,10,2000,1200],'Color','w','Visible',settings.Visible);
    for parameter_index = 1:8
        ax = subplot(2,4,parameter_index);
        hold(ax,'on');
        values = cell(1,3);
        for objective_index = 1:3
            values{objective_index} = parameter_groups{objective_index}(:,parameter_index);
            values{objective_index} = values{objective_index}(isfinite(values{objective_index}) & values{objective_index}>0);
        end
        matrix = pad_cell_vectors(values);
        % Display only standard boxplot outliers: values beyond 1.5 IQR from
        % the lower/upper quartile. All in-range estimates are summarized
        % by the box, median, and whiskers rather than plotted individually.
        boxplot(ax,matrix,'Labels',{'No var.','Variance','Rel. var.'}, ...
            'Symbol','o','Whisker',1.5,'OutlierSize',7);
        color_boxplot(ax,objective_colors);
        color_boxplot_outliers(ax,objective_colors);
        if ~isempty(settings.ReferenceParameters)
            yline(ax,settings.ReferenceParameters(parameter_index),'k--','LineWidth',1.5, ...
                'HandleVisibility','off');
        end
        set(ax,'YScale','log');
        title(ax,parameter_labels{parameter_index},'Interpreter','tex', ...
            'FontName','Arial','FontSize',23,'FontWeight','bold');
        ylabel(ax,'Fitted value','FontName','Arial','FontSize',19);
        style_axis(ax,18);
    end

    parameter_stem = fullfile(output_dir,'ParDist_STAR');
    exportgraphics(parameter_fig,[parameter_stem,'.png'],'Resolution',300);
    savefig(parameter_fig,[parameter_stem,'.fig']);
    if settings.SavePDF, exportgraphics(parameter_fig,[parameter_stem,'.pdf'],'ContentType','vector'); end

    writetable(summary_table,fullfile(output_dir,'STAR_synthetic_fit_summary.csv'));
    fprintf('STAR synthetic figures saved as %s.png and %s.png\n',fit_stem,parameter_stem);
end

function [time_min,data_mean,data_sd,prediction_groups,parameter_groups,summary_table] = ...
    collect_synthetic_plot_data(records,objectives,criterion)
    dataset_ids = unique([records.dataset_id]);
    assert(~isempty(dataset_ids),'No synthetic dataset identifiers were found.');
    template = select_record(records,dataset_ids(1),objectives{1},criterion);
    assert(~isempty(template),'No successful fitting record was found for the first synthetic dataset.');

    time_min = template.data_summary.time_min(:)';
    n_time = numel(time_min);
    n_replicates = size(template.data_summary.replicates,1);
    n_datasets = numel(dataset_ids);
    all_replicates = nan(n_datasets*n_replicates,n_time);
    prediction_groups = cell(1,numel(objectives));
    parameter_groups = cell(1,numel(objectives));
    common_sse_groups = cell(1,numel(objectives));

    for objective_index = 1:numel(objectives)
        prediction_groups{objective_index} = nan(n_datasets,n_time);
        parameter_groups{objective_index} = nan(n_datasets,8);
        common_sse_groups{objective_index} = nan(n_datasets,1);
        for dataset_index = 1:n_datasets
            dataset_id = dataset_ids(dataset_index);
            record = select_record(records,dataset_id,objectives{objective_index},criterion);
            if isempty(record), continue; end
            prediction_groups{objective_index}(dataset_index,:) = record.prediction(:)';
            parameter_groups{objective_index}(dataset_index,:) = record.p_opt(:)';
            common_sse_groups{objective_index}(dataset_index) = record.common_sse;
            if objective_index == 1
                row_range = (dataset_index-1)*n_replicates+(1:n_replicates);
                all_replicates(row_range,:) = record.data_summary.replicates;
            end
        end
    end

    % The empirical synthetic-data band derives directly from every generated
    % replicate trajectory, rather than from the much narrower SD of 100
    % replicate means.
    data_mean = mean(all_replicates,1,'omitnan');
    data_sd = std(all_replicates,0,1,'omitnan');
    summary_table = table(string(objectives(:)), ...
        cellfun(@(x)sum(isfinite(x)),common_sse_groups(:)), ...
        cellfun(@(x)median(x,'omitnan'),common_sse_groups(:)), ...
        cellfun(@(x)mean(x,'omitnan'),common_sse_groups(:)), ...
        cellfun(@(x)std(x,'omitnan'),common_sse_groups(:)), ...
        'VariableNames',{'Objective','SuccessfulDatasets','MedianCommonSSE','MeanCommonSSE','SDCommonSSE'});
end

function record = select_record(records,dataset_id,objective_type,criterion)
    idx = [records.dataset_id]==dataset_id & ...
        strcmp({records.objective_type},objective_type) & strcmp({records.status},'success');
    candidates = records(idx);
    if isempty(candidates), record = []; return; end
    switch lower(criterion)
        case 'common_sse'
            [~,best_index] = min([candidates.common_sse]);
        case 'training_objective'
            [~,best_index] = min([candidates.training_objective]);
        otherwise
            error('Unknown SelectionCriterion: %s',criterion);
    end
    record = candidates(best_index);
end

function matrix = pad_cell_vectors(values)
    n = max(cellfun(@numel,values));
    matrix = nan(n,numel(values));
    for i = 1:numel(values), matrix(1:numel(values{i}),i) = values{i}(:); end
end

function color_boxplot(ax,colors)
    boxes = flipud(findobj(ax,'Tag','Box'));
    medians = flipud(findobj(ax,'Tag','Median'));
    whiskers = flipud(findobj(ax,'Tag','Whisker'));
    for i = 1:min(numel(boxes),size(colors,1))
        % boxplot creates line objects rather than filled patches. Add a
        % low-opacity patch behind each box while retaining its colored edge.
        patch(ax,get(boxes(i),'XData'),get(boxes(i),'YData'),colors(i,:), ...
            'FaceAlpha',0.16,'EdgeColor','none','HandleVisibility','off');
        set(boxes(i),'Color',colors(i,:),'LineWidth',2.0);
    end
    for i = 1:min(numel(medians),size(colors,1))
        set(medians(i),'Color',colors(i,:),'LineWidth',2.0);
    end
    for i = 1:min(numel(whiskers),2*size(colors,1))
        color_index = ceil(i/2);
        set(whiskers(i),'Color',colors(color_index,:),'LineWidth',1.5);
    end
end

function color_boxplot_outliers(ax,colors)
    outliers = flipud(findobj(ax,'Tag','Outliers'));
    for i = 1:min(numel(outliers),size(colors,1))
        set(outliers(i),'Marker','o','MarkerSize',7, ...
            'MarkerEdgeColor',colors(i,:),'MarkerFaceColor','none', ...
            'LineWidth',1.25);
    end
end

function style_axis(ax,font_size)
    grid(ax,'on'); box(ax,'on');
    set(ax,'FontSize',font_size,'FontName','Arial','LineWidth',0.9,'Layer','top');
    ax.XAxisLocation = 'bottom';
    ax.YAxisLocation = 'left';
    try
        ax.Toolbar.Visible = 'off';
    catch
    end
end

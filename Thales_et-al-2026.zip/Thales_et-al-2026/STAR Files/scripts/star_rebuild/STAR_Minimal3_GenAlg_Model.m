function dx = STAR_Minimal3_GenAlg_Model(~,x,p)
%STAR_MINIMAL3_GENALG_MODEL Numerical minimal three-state STAR model.
%
% Effective long-time formulation, identical to STAR_Minimal3_GenSSI.m.
%
% State vector
%   x(1) = Z : effective STAR-expression state
%   x(2) = A : effective activated target / GFP-production state
%   x(3) = G : mature GFP, measured output
%
% Fitted parameter vector
%   p(1) = theta_tx  : effective transcription/output gain
%   p(2) = beta_bind : STAR-target binding/activation rate
%   p(3) = delta_RNA : effective common RNA-loss rate
%   p(4) = delta_G   : GFP loss/degradation rate
%
% Known inputs, supplied by the fitting scripts through global par
%   par.Ps    : STAR plasmid concentration (M), condition dependent
%   par.PYtot : target plasmid concentration (M), fixed at 0.5 nM

    global par

    Z = x(1);
    A = x(2);
    G = x(3);

    theta_tx  = p(1);
    beta_bind = p(2);
    delta_RNA = p(3);
    delta_G   = p(4);

    Ps = par.Ps;
    Py = par.PYtot;

    dx = zeros(3,1);
    dx(1) = theta_tx*Ps - (beta_bind*Py + delta_RNA)*Z;
    dx(2) = beta_bind*Py*Z - delta_RNA*A;
    dx(3) = A - delta_G*G;
end

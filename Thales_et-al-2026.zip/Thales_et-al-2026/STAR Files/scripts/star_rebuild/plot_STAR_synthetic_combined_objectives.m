function plot_STAR_synthetic_combined_objectives(results_file,varargin)
%PLOT_STAR_SYNTHETIC_COMBINED_OBJECTIVES Plot all STAR objective fits together.
%
% Creates one trajectory plot for a completed STAR synthetic fitting result.
% The black dashed line is the synthetic data mean. The purple, teal, and
% coral lines are the fitted trajectory means for No Variance, Variance, and
% Relative Variance, respectively. The pale blue band shows the spread of all
% synthetic replicate trajectories. Objective colored bands show the spread
% of fitted trajectories across the 100 selected dataset fits.
%
% The function works for both completed synthetic result files:
%   Original model: STAR_synthetic_three_objective_results.mat
%   Minimal model:  STAR_minimal3_synthetic_results.mat
%
% This function changes only the figure layout. It does not rerun the
% genetic algorithm and it does not change the saved fitting results.
%
% Example for the original STAR model:
%   plot_STAR_synthetic_combined_objectives( ...
%       full_results_file, ...
%       'DataFile',synthetic_data_file, ...
%       'OutputDirectory',output_folder, ...
%       'Visible','on');
%
% Example for the minimal STAR model:
%   plot_STAR_synthetic_combined_objectives( ...
%       minimal_results_file, ...
%       'DataFile',synthetic_data_file, ...
%       'OutputDirectory',output_folder, ...
%       'Visible','on');
%
% Optional name value pair:
%   'SelectionCriterion'  'training_objective' or 'common_sse'
%   'ShowFitBands'        true or false; default is true
%   'Visible'             'on' or 'off'
%   'SavePDF'             true or false; default is false

    ip = inputParser;
    ip.addRequired('results_file',@(x)ischar(x)||isstring(x));
    ip.addParameter('DataFile','Simulated_Data_Jan22_2025.mat', ...
        @(x)ischar(x)||isstring(x));
    ip.addParameter('OutputDirectory','',@(x)ischar(x)||isstring(x));
    ip.addParameter('SelectionCriterion','training_objective', ...
        @(x)any(strcmpi(x,{'training_objective','common_sse'})));
    ip.addParameter('ShowFitBands',true,@(x)islogical(x)&&isscalar(x));
    ip.addParameter('Visible','on',@(x)any(strcmpi(x,{'on','off'})));
    ip.addParameter('SavePDF',false,@(x)islogical(x)&&isscalar(x));
    ip.parse(results_file,varargin{:});
    settings = ip.Results;

    results_file = char(settings.results_file);
    data_file = char(settings.DataFile);
    assert(isfile(results_file),'Results file was not found: %s',results_file);
    assert(isfile(data_file),'Synthetic data file was not found: %s',data_file);

    source = load(results_file,'run_records');
    assert(isfield(source,'run_records') && ~isempty(source.run_records), ...
        'No fitting records were found in %s.',results_file);
    records = source.run_records;

    synthetic_input = load(data_file,'Simu_Traje','Simu_t');
    assert(isfield(synthetic_input,'Simu_Traje') && isfield(synthetic_input,'Simu_t'), ...
        'DataFile must contain Simu_Traje and Simu_t.');

    if isempty(settings.OutputDirectory)
        [parent_dir,~,~] = fileparts(results_file);
        if isempty(parent_dir), parent_dir = pwd; end
        output_dir = fullfile(parent_dir,'plots');
    else
        output_dir = char(settings.OutputDirectory);
    end
    if ~isfolder(output_dir), mkdir(output_dir); end

    objectives = {'no_variance','variance','relative_variance'};
    objective_labels = {'No Variance fit','Variance fit','Relative Variance fit'};

    % These colors and line widths match the final STAR synthetic figures.
    objective_colors = [ ...
        0.4940 0.1840 0.5560; ...  % purple: No Variance
        0.3010 0.7450 0.9330; ...  % teal: Variance
        0.8500 0.3250 0.0980];     % coral: Relative Variance
    data_color = [0 0 0];
    data_band_color = [0.5500 0.7200 0.8500];

    [time_min,data_mean,data_sd,fit_mean,fit_sd,n_parameters] = ...
        collect_combined_plot_data(records,synthetic_input,objectives, ...
        settings.SelectionCriterion);

    if n_parameters == 8
        output_name = 'STAR_FullModel_Synthetic_CombinedObjectives';
    elseif n_parameters == 4
        output_name = 'STAR_Minimal3_Synthetic_CombinedObjectives';
    else
        output_name = 'STAR_Synthetic_CombinedObjectives';
    end

    % Use the same white background, Arial font, boxed axes, and large text
    % as the previous final STAR synthetic figures. No figure title is added.
    fig = figure('Position',[10,10,1600,820], ...
        'Color','w','Visible',settings.Visible);
    ax = axes(fig);
    hold(ax,'on');

    time_fill = [time_min,fliplr(time_min)];

    % Synthetic replicate spread: mean +/- 1 SD.
    fill(ax,time_fill, ...
        [data_mean-data_sd,fliplr(data_mean+data_sd)], ...
        data_band_color,'FaceAlpha',0.30,'EdgeColor','none', ...
        'HandleVisibility','off');

    % Fit spread: mean +/- 1 SD. The lower alpha keeps the three bands
    % interpretable when shown in a shared axes.
    if settings.ShowFitBands
        for objective_index = 1:numel(objectives)
            lower_band = fit_mean(objective_index,:) - fit_sd(objective_index,:);
            upper_band = fit_mean(objective_index,:) + fit_sd(objective_index,:);
            fill(ax,time_fill,[lower_band,fliplr(upper_band)], ...
                objective_colors(objective_index,:), ...
                'FaceAlpha',0.18,'EdgeColor','none', ...
                'HandleVisibility','off');
        end
    end

    h_data = plot(ax,time_min,data_mean,'--', ...
        'Color',data_color,'LineWidth',2.1, ...
        'DisplayName','Synthetic data mean');

    h_fit = gobjects(1,numel(objectives));
    for objective_index = 1:numel(objectives)
        h_fit(objective_index) = plot(ax,time_min,fit_mean(objective_index,:),'-', ...
            'Color',objective_colors(objective_index,:), ...
            'LineWidth',3.3, ...
            'DisplayName',objective_labels{objective_index});
    end

    xlabel(ax,'Time (min)','FontName','Arial','FontSize',24);
    ylabel(ax,'GFP fluorescence','FontName','Arial','FontSize',24);
    xlim(ax,[time_min(1),time_min(end)]);

    % All vectors are explicitly converted to column vectors before they are
    % combined. This avoids the row versus column concatenation error.
    upper_values = [ ...
        (data_mean(:) + data_sd(:)); ...
        (fit_mean(:) + fit_sd(:))];
    lower_values = [ ...
        (data_mean(:) - data_sd(:)); ...
        (fit_mean(:) - fit_sd(:))];
    y_upper = max(upper_values,[],'omitnan');
    y_lower = min(lower_values,[],'omitnan');
    if ~isfinite(y_upper) || y_upper <= 0, y_upper = 1; end
    if ~isfinite(y_lower), y_lower = 0; end
    ylim(ax,[min(0,y_lower),1.08*y_upper]);

    grid(ax,'on');
    box(ax,'on');
    set(ax,'FontName','Arial','FontSize',18,'LineWidth',0.9,'Layer','top');
    ax.XAxisLocation = 'bottom';
    ax.YAxisLocation = 'left';
    try
        ax.Toolbar.Visible = 'off';
    catch
    end

    % Keep the full axes area and place the unframed legend inside the
    % upper left of the plot, where the early trajectory is near zero.
    legend_handle = legend(ax,[h_data,h_fit], ...
        {'Synthetic data mean','No Variance fit','Variance fit','Relative Variance fit'}, ...
        'Location','northwest','FontSize',18,'FontName','Arial', ...
        'FontWeight','bold','Box','off');

    output_stem = fullfile(output_dir,output_name);
    exportgraphics(fig,[output_stem,'.png'],'Resolution',300);
    savefig(fig,[output_stem,'.fig']);
    if settings.SavePDF
        exportgraphics(fig,[output_stem,'.pdf'],'ContentType','vector');
    end

    fprintf('Combined STAR synthetic figure saved as:\n%s.png\n%s.fig\n', ...
        output_stem,output_stem);
end


function [time_min,data_mean,data_sd,fit_mean,fit_sd,n_parameters] = ...
    collect_combined_plot_data(records,synthetic_input,objectives,criterion)

    dataset_ids = unique([records.dataset_id]);
    assert(~isempty(dataset_ids),'No synthetic dataset identifiers were found.');

    template = select_record(records,dataset_ids(1),objectives{1},criterion);
    assert(~isempty(template), ...
        'No successful No Variance record was found for the first dataset.');
    n_parameters = numel(template.p_opt);

    time_min = double(synthetic_input.Simu_t(:)');
    n_time = numel(time_min);
    n_replicates = 3;
    assert(size(synthetic_input.Simu_Traje,2) == n_time, ...
        'Simu_Traje columns must match Simu_t.');

    n_datasets = numel(dataset_ids);
    all_replicates = nan(n_datasets*n_replicates,n_time);
    fit_mean = nan(numel(objectives),n_time);
    fit_sd = nan(numel(objectives),n_time);

    for dataset_index = 1:n_datasets
        dataset_id = dataset_ids(dataset_index);
        source_rows = (dataset_id-1)*n_replicates + (1:n_replicates);
        assert(max(source_rows) <= size(synthetic_input.Simu_Traje,1), ...
            'Dataset %d exceeds the available rows in Simu_Traje.',dataset_id);
        target_rows = (dataset_index-1)*n_replicates + (1:n_replicates);
        all_replicates(target_rows,:) = ...
            double(synthetic_input.Simu_Traje(source_rows,:));
    end

    for objective_index = 1:numel(objectives)
        fitted_trajectories = nan(n_datasets,n_time);
        for dataset_index = 1:n_datasets
            record = select_record(records,dataset_ids(dataset_index), ...
                objectives{objective_index},criterion);
            if isempty(record), continue; end
            fitted_trajectories(dataset_index,:) = record.prediction(:)';
        end
        fit_mean(objective_index,:) = mean(fitted_trajectories,1,'omitnan');
        fit_sd(objective_index,:) = std(fitted_trajectories,0,1,'omitnan');
    end

    data_mean = mean(all_replicates,1,'omitnan');
    data_sd = std(all_replicates,0,1,'omitnan');
end


function record = select_record(records,dataset_id,objective_type,criterion)
    index = [records.dataset_id] == dataset_id & ...
        strcmp({records.objective_type},objective_type) & ...
        strcmp({records.status},'success');
    candidates = records(index);
    if isempty(candidates)
        record = [];
        return;
    end

    switch lower(criterion)
        case 'training_objective'
            [~,selected_index] = min([candidates.training_objective]);
        case 'common_sse'
            [~,selected_index] = min([candidates.common_sse]);
        otherwise
            error('Unknown SelectionCriterion: %s',criterion);
    end
    record = candidates(selected_index);
end

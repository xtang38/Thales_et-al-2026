function plot_STAR_reduced6_synthetic_GA_results(results_file,varargin)
%PLOT_STAR_REDUCED6_SYNTHETIC_GA_RESULTS Plot reduced-6 STAR benchmark.
%
% Produces a three-panel trajectory comparison and a six-panel parameter
% distribution figure using the same objective colors and publication style
% as the original eight-parameter STAR benchmark. Dataset-level points are
% omitted except for standard 1.5-IQR boxplot outliers.

    ip = inputParser;
    ip.addRequired('results_file',@(x)ischar(x)||isstring(x));
    ip.addParameter('OutputDirectory','',@(x)ischar(x)||isstring(x));
    ip.addParameter('SelectionCriterion','training_objective', ...
        @(x)any(strcmpi(x,{'common_sse','training_objective'})));
    ip.addParameter('Visible','on',@(x)any(strcmpi(x,{'on','off'})));
    ip.parse(results_file,varargin{:});
    settings = ip.Results;

    source = load(settings.results_file,'run_records','param_names');
    assert(isfield(source,'run_records') && ~isempty(source.run_records), ...
        'No reduced-6 fitting records were found in %s.',settings.results_file);
    assert(numel(source.param_names)==6, ...
        'Expected six reduced-model parameters in the results file.');

    if isempty(settings.OutputDirectory)
        [parent_dir,~,~] = fileparts(settings.results_file);
        output_dir = fullfile(parent_dir,'plots');
    else
        output_dir = char(settings.OutputDirectory);
    end
    if ~isfolder(output_dir), mkdir(output_dir); end

    objectives = {'no_variance','variance','relative_variance'};
    objective_labels = {'No Variance','Variance','Relative Variance'};
    colors = [0.4940 0.1840 0.5560; 0.3010 0.7450 0.9330; 0.8500 0.3250 0.0980];
    % Synthetic-data mean is deliberately black for maximum contrast.
    data_color = [0.0000 0.0000 0.0000];
    data_band_color = [0.5500 0.7200 0.8500];
    parameter_labels = {'\alpha_{tx}','\delta_{RNA}','\beta_s','K_i','K_e','\alpha_{gm}'};

    [time_min,data_mean,data_sd,predictions,parameters,summary_table] = ...
        collect_data(source.run_records,objectives,settings.SelectionCriterion);

    %% Trajectory figure
    fit_fig = figure('Position',[10,10,2000,720],'Color','w','Visible',settings.Visible);
    for i=1:3
        ax = subplot(1,3,i); hold(ax,'on');
        fit_mean = mean(predictions{i},1,'omitnan');
        fit_sd = std(predictions{i},0,1,'omitnan');
        tf = [time_min,fliplr(time_min)];
        fill(ax,tf,[data_mean-data_sd,fliplr(data_mean+data_sd)],data_band_color, ...
            'FaceAlpha',0.30,'EdgeColor','none','HandleVisibility','off');
        fill(ax,tf,[fit_mean-fit_sd,fliplr(fit_mean+fit_sd)],colors(i,:), ...
            'FaceAlpha',0.40,'EdgeColor','none','HandleVisibility','off');
        plot(ax,time_min,data_mean,'--','Color',data_color,'LineWidth',2.1, ...
            'DisplayName','Synthetic data mean');
        plot(ax,time_min,fit_mean,'-','Color',colors(i,:),'LineWidth',3.3, ...
            'DisplayName',[objective_labels{i},' fit']);
        text(ax,0.05,0.95,sprintf('%s\nSSE = %.4g',objective_labels{i},summary_table.MedianCommonSSE(i)), ...
            'Units','normalized','VerticalAlignment','top','FontName','Arial', ...
            'FontSize',18,'FontWeight','bold','BackgroundColor','white','EdgeColor','none');
        xlabel(ax,'Time (min)','FontName','Arial','FontSize',24);
        ylabel(ax,'GFP fluorescence','FontName','Arial','FontSize',24);
        xlim(ax,[time_min(1),time_min(end)]);
        ymax=max([data_mean+data_sd,fit_mean+fit_sd],[],'omitnan');
        if isfinite(ymax)&&ymax>0, ylim(ax,[0,1.08*ymax]); end
        style_axis(ax,18);
    end
    adjust_axes_for_legend(fit_fig);
    make_legend(fit_fig,data_color,colors);
    fit_stem=fullfile(output_dir,'STAR_Reduced6_FinalPlot');
    exportgraphics(fit_fig,[fit_stem,'.png'],'Resolution',300); savefig(fit_fig,[fit_stem,'.fig']);

    %% Six-parameter distribution figure
    par_fig=figure('Position',[10,10,1800,1050],'Color','w','Visible',settings.Visible);
    for p=1:6
        ax=subplot(2,3,p); hold(ax,'on');
        values=cell(1,3);
        for i=1:3
            values{i}=parameters{i}(:,p);
            values{i}=values{i}(isfinite(values{i}) & values{i}>0);
        end
        boxplot(ax,pad_vectors(values),'Labels',{'No var.','Variance','Rel. var.'}, ...
            'Symbol','o','Whisker',1.5,'OutlierSize',7);
        color_boxplot(ax,colors); color_outliers(ax,colors);
        set(ax,'YScale','log');
        title(ax,parameter_labels{p},'Interpreter','tex','FontName','Arial', ...
            'FontSize',23,'FontWeight','bold');
        ylabel(ax,'Fitted value','FontName','Arial','FontSize',19);
        style_axis(ax,18);
    end
    par_stem=fullfile(output_dir,'ParDist_STAR_Reduced6');
    exportgraphics(par_fig,[par_stem,'.png'],'Resolution',300); savefig(par_fig,[par_stem,'.fig']);

    writetable(summary_table,fullfile(output_dir,'STAR_reduced6_synthetic_fit_summary.csv'));
    fprintf('Reduced-6 STAR figures saved as %s.png and %s.png\n',fit_stem,par_stem);
end

function [t,dm,ds,pg,pa,summary]=collect_data(records,objectives,criterion)
    ids=unique([records.dataset_id]);
    first=select_record(records,ids(1),objectives{1},criterion);
    assert(~isempty(first),'No successful record found.');
    t=first.data_summary.time_min(:)'; nt=numel(t); nr=size(first.data_summary.replicates,1); nd=numel(ids);
    allrep=nan(nd*nr,nt); pg=cell(1,3); pa=cell(1,3); sse=cell(1,3);
    for i=1:3
        pg{i}=nan(nd,nt); pa{i}=nan(nd,6); sse{i}=nan(nd,1);
        for j=1:nd
            rec=select_record(records,ids(j),objectives{i},criterion);
            if isempty(rec), continue; end
            pg{i}(j,:)=rec.prediction(:)'; pa{i}(j,:)=rec.p_opt(:)'; sse{i}(j)=rec.common_sse;
            if i==1, allrep((j-1)*nr+(1:nr),:)=rec.data_summary.replicates; end
        end
    end
    dm=mean(allrep,1,'omitnan'); ds=std(allrep,0,1,'omitnan');
    summary=table(string(objectives(:)),cellfun(@(x)sum(isfinite(x)),sse(:)), ...
        cellfun(@(x)median(x,'omitnan'),sse(:)),cellfun(@(x)mean(x,'omitnan'),sse(:)), ...
        cellfun(@(x)std(x,'omitnan'),sse(:)), ...
        'VariableNames',{'Objective','SuccessfulDatasets','MedianCommonSSE','MeanCommonSSE','SDCommonSSE'});
end

function rec=select_record(records,id,objective,criterion)
    idx=[records.dataset_id]==id & strcmp({records.objective_type},objective) & strcmp({records.status},'success');
    candidates=records(idx); if isempty(candidates), rec=[]; return; end
    if strcmpi(criterion,'training_objective'), [~,k]=min([candidates.training_objective]);
    else, [~,k]=min([candidates.common_sse]); end
    rec=candidates(k);
end

function M=pad_vectors(values)
    n=max(cellfun(@numel,values)); M=nan(n,numel(values));
    for i=1:numel(values), M(1:numel(values{i}),i)=values{i}(:); end
end

function color_boxplot(ax,colors)
    boxes=flipud(findobj(ax,'Tag','Box')); medians=flipud(findobj(ax,'Tag','Median')); whiskers=flipud(findobj(ax,'Tag','Whisker'));
    for i=1:min(numel(boxes),3)
        % Add a low-opacity fill behind the line-only boxplot geometry.
        patch(ax,get(boxes(i),'XData'),get(boxes(i),'YData'),colors(i,:), ...
            'FaceAlpha',0.16,'EdgeColor','none','HandleVisibility','off');
        set(boxes(i),'Color',colors(i,:),'LineWidth',2);
    end
    for i=1:min(numel(medians),3), set(medians(i),'Color',colors(i,:),'LineWidth',2); end
    for i=1:min(numel(whiskers),6), set(whiskers(i),'Color',colors(ceil(i/2),:),'LineWidth',1.5); end
end

function color_outliers(ax,colors)
    h=flipud(findobj(ax,'Tag','Outliers'));
    for i=1:min(numel(h),3), set(h(i),'Marker','o','MarkerSize',7,'MarkerEdgeColor',colors(i,:), ...
        'MarkerFaceColor','none','LineWidth',1.25); end
end

function style_axis(ax,fs)
    grid(ax,'on'); box(ax,'on'); set(ax,'FontSize',fs,'FontName','Arial','LineWidth',0.9,'Layer','top');
    ax.XAxisLocation='bottom'; ax.YAxisLocation='left';
    try, ax.Toolbar.Visible='off'; catch, end
end

function adjust_axes_for_legend(fig)
    axes_list=findall(fig,'Type','axes');
    for k=1:numel(axes_list)
        pos=axes_list(k).Position; pos(2)=pos(2)+0.065; pos(4)=pos(4)-0.015; axes_list(k).Position=pos;
    end
end

function make_legend(fig,data_color,colors)
    ax=axes('Parent',fig,'Position',[0,0,1,1],'Visible','off'); hold(ax,'on');
    h1=plot(ax,NaN,NaN,'--','Color',data_color,'LineWidth',2.1);
    h2=plot(ax,NaN,NaN,'-','Color',colors(1,:),'LineWidth',3.3);
    h3=plot(ax,NaN,NaN,'-','Color',colors(2,:),'LineWidth',3.3);
    h4=plot(ax,NaN,NaN,'-','Color',colors(3,:),'LineWidth',3.3);
    L=legend(ax,[h1 h2 h3 h4],{'Synthetic data mean','No Variance fit','Variance fit','Relative Variance fit'}, ...
        'NumColumns',4,'FontSize',18,'FontName','Arial','FontWeight','bold','Box','off');
    L.Units='normalized'; L.Position=[0.08 0.012 0.84 0.045];
end

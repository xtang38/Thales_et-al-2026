function plot_STAR_four_condition_GA_results(results_file,varargin)
%PLOT_STAR_FOUR_CONDITION_GA_RESULTS Plot joint STAR experimental calibration.
%
% Produces one three-panel STAR experimental figure. Each panel represents
% one objective (No Variance, Variance, Relative Variance) and overlays the
% four experimental conditions, exactly following the visual convention of
% the existing AND-gate/CRISPRi final plots:
%   dashed line  = replicate mean;
%   transparent band = replicate mean +/- 1 sample SD;
%   solid line   = fitted ODE trajectory;
%   same color   = same experimental condition in every panel.
%
% The displayed fit is the GA restart with the lowest value of its OWN
% training objective. The annotated common unweighted SSE is then evaluated
% separately across all four raw-condition means, allowing fair comparison
% without changing which solution represents each objective.
%
% Example:
%   plot_STAR_four_condition_GA_results( ...
%       'STAR_experimental_four_condition_results/STAR_experimental_four_condition_results.mat');

    ip = inputParser;
    ip.addRequired('results_file',@(x)ischar(x)||isstring(x));
    ip.addParameter('OutputDirectory','',@(x)ischar(x)||isstring(x));
    ip.addParameter('SelectionCriterion','training_objective', ...
        @(x)any(strcmpi(x,{'common_sse','training_objective'})));
    ip.addParameter('Visible','on',@(x)any(strcmpi(x,{'on','off'})));
    ip.addParameter('SavePDF',false,@(x)islogical(x)&&isscalar(x));
    ip.parse(results_file,varargin{:});
    settings = ip.Results;

    source = load(settings.results_file,'run_records','conditions');
    assert(isfield(source,'run_records') && ~isempty(source.run_records), ...
        'No STAR fitting records were found in %s.',settings.results_file);
    assert(isfield(source,'conditions') && numel(source.conditions)==4, ...
        'The results file must contain the four STAR conditions.');

    if isempty(settings.OutputDirectory)
        [parent_dir,~,~] = fileparts(settings.results_file);
        output_dir = fullfile(parent_dir,'plots');
    else
        output_dir = char(settings.OutputDirectory);
    end
    if ~isfolder(output_dir), mkdir(output_dir); end

    objectives = {'no_variance','variance','relative_variance'};
    labels = {'No Variance','Variance','Relative Variance'};
    condition_colors = lines(numel(source.conditions));

    fig = figure('Position',[10,10,2000,720],'Color','w','Visible',settings.Visible);
    for objective_index = 1:numel(objectives)
        ax = subplot(1,3,objective_index);
        hold(ax,'on');
        best_record = select_record(source.run_records,objectives{objective_index},settings.SelectionCriterion);
        if isempty(best_record)
            text(ax,0.5,0.5,'No successful GA result','Units','normalized', ...
                'HorizontalAlignment','center','FontName','Arial','FontSize',16);
            style_axis(ax);
            continue;
        end

        all_time = [];
        y_upper = 0;
        for condition_index = 1:numel(source.conditions)
            condition = source.conditions(condition_index);
            time_min = condition.time_min(:)';
            mean_trace = condition.mean_data(:)';
            sd_trace = condition.sample_sd(:)';
            prediction = best_record.predictions(condition_index,:);
            color = condition_colors(condition_index,:);

            % Mean +/- 1 SD replicate band: identical fill treatment to the
            % AND-gate/CRISPRi plotting code.
            fill(ax,[time_min,fliplr(time_min)], ...
                [mean_trace-sd_trace,fliplr(mean_trace+sd_trace)], ...
                color,'FaceAlpha',0.20,'EdgeColor','none','HandleVisibility','off');
            plot(ax,time_min,mean_trace,'--','Color',color,'LineWidth',1.8, ...
                'DisplayName',[condition.display_name,' (Exp)']);
            plot(ax,time_min,prediction,'-','Color',color,'LineWidth',3.0, ...
                'DisplayName',[condition.display_name,' (Sim)']);

            all_time = [all_time,time_min]; %#ok<AGROW>
            y_upper = max([y_upper,mean_trace+sd_trace,prediction],[],'omitnan');
        end

        text(ax,0.05,0.95,sprintf('Experimental data - %s\nSSE = %.4f', ...
            labels{objective_index},best_record.common_sse), ...
            'Units','normalized','VerticalAlignment','top','HorizontalAlignment','left', ...
            'FontName','Arial','FontSize',16,'FontWeight','bold', ...
            'BackgroundColor','white','EdgeColor','none');
        xlabel(ax,'Time (min)','FontName','Arial','FontSize',20);
        ylabel(ax,'GFP fluorescence','FontName','Arial','FontSize',20);
        xlim(ax,[min(all_time),max(all_time)]);
        if isfinite(y_upper) && y_upper>0, ylim(ax,[0,1.08*y_upper]); end
        style_axis(ax);
    end

    % Figure-level legend using the same Exp/Sim arrangement as the existing
    % AND-gate/CRISPRi final plots.
    legend_axis = axes('Position',[0,0,1,1],'Visible','off');
    hold(legend_axis,'on');
    exp_handles = gobjects(1,numel(source.conditions));
    sim_handles = gobjects(1,numel(source.conditions));
    exp_labels = cell(1,numel(source.conditions));
    sim_labels = cell(1,numel(source.conditions));
    for condition_index = 1:numel(source.conditions)
        color = condition_colors(condition_index,:);
        label = source.conditions(condition_index).display_name;
        exp_handles(condition_index) = plot(legend_axis,NaN,NaN,'--','Color',color,'LineWidth',1.8);
        sim_handles(condition_index) = plot(legend_axis,NaN,NaN,'-','Color',color,'LineWidth',3.0);
        exp_labels{condition_index} = [label,' (Exp)'];
        sim_labels{condition_index} = [label,' (Sim)'];
    end
    legend(legend_axis,[exp_handles,sim_handles],[exp_labels,sim_labels], ...
        'NumColumns',8,'Location','southoutside','FontSize',16, ...
        'FontName','Arial','FontWeight','bold','Box','off');

    output_stem = fullfile(output_dir,'STAR_Experimental_FinalPlot');
    exportgraphics(fig,[output_stem,'.png'],'Resolution',300);
    savefig(fig,[output_stem,'.fig']);
    if settings.SavePDF, exportgraphics(fig,[output_stem,'.pdf'],'ContentType','vector'); end
    fprintf('STAR experimental figure saved as %s.png and %s.fig\n',output_stem,output_stem);
end

function record = select_record(records,objective_type,criterion)
    idx = strcmp({records.objective_type},objective_type) & strcmp({records.status},'success');
    candidates = records(idx);
    if isempty(candidates), record = []; return; end
    switch lower(criterion)
        case 'common_sse'
            [~,best_index] = min([candidates.common_sse]);
        case 'training_objective'
            [~,best_index] = min([candidates.training_objective]);
        otherwise
            error('Unknown SelectionCriterion: %s',criterion);
    end
    record = candidates(best_index);
end

function style_axis(ax)
    grid(ax,'on'); box(ax,'on');
    set(ax,'FontSize',15,'FontName','Arial','LineWidth',1.0,'Layer','top');
    ax.XAxisLocation = 'bottom';
    ax.YAxisLocation = 'left';
    % Avoid including an interactive axes toolbar in exported PNG figures.
    try
        ax.Toolbar.Visible = 'off';
    catch
        % Older MATLAB releases may not expose this property; plotting still works.
    end
end

function run_summary = run_STAR_experimental_three_objective_ga(raw_data_file, varargin)
%RUN_STAR_EXPERIMENTAL_THREE_OBJECTIVE_GA Fit 8 nM STAR replicates only.
%
% This wrapper runs ONLY the raw 8 nM STAR experimental replicate data under
% the three requested objectives: No Variance, Variance, and Relative
% Variance. It intentionally does NOT generate 20%/40% artificial-noise
% scenarios and does NOT run 4 nM/16 nM predictions.
%
% The function reuses the core data loading, variance calculation, bounded-GA,
% checkpointing, and result format in run_star_nine_scenario_ga.m, but forces
% its NoiseLevels setting to zero.
%
% Example:
%   run_STAR_experimental_three_objective_ga('STAR_Data3011.csv', ...
%       'TimeColumn','Time','GFPColumns',{'Rep1','Rep2','Rep3','Rep4', ...
%       'Rep5','Rep6','Rep7','Rep8','Rep9'}, ...
%       'NumRestarts',30,'PopulationSize',100,'MaxGenerations',100, ...
%       'OutputDirectory','STAR_experimental_three_objective_results');
%
% If the CSV only has one time column plus the nine 8 nM replicate columns,
% omit TimeColumn and GFPColumns and they will be inferred automatically.

    % Add a descriptive output directory only if the caller has not supplied
    % one. This avoids passing a duplicate InputParser parameter name.
    provided_names = string(varargin(1:2:end));
    if any(strcmpi(provided_names,'OutputDirectory'))
        run_summary = run_star_nine_scenario_ga(raw_data_file, ...
            'NoiseLevels',0, varargin{:});
    else
        run_summary = run_star_nine_scenario_ga(raw_data_file, ...
            'NoiseLevels',0, ...
            'OutputDirectory','STAR_experimental_three_objective_results', ...
            varargin{:});
    end
end

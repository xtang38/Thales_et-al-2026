function run_summary = run_star_nine_scenario_ga(raw_data_file, varargin)
%RUN_STAR_NINE_SCENARIO_GA STAR fitting for the nine manuscript scenarios.
%
% This function reproduces the organization of the second part of the paper
% for the single 8 nM STAR calibration condition only. It fits the STAR ODE
% model to:
%   (i)  raw experimental GFP replicates;
%   (ii) six artificial GFP replicates with 20% signal-proportional noise;
%   (iii) six artificial GFP replicates with 40% signal-proportional noise.
%
% Every data condition is calibrated by each of the three objectives:
%   no_variance:       sum_i (yhat_i - ybar_i)^2
%   variance:          sum_i (yhat_i - ybar_i)^2 / max(s_i^2, eps_v)
%   relative_variance: sum_i (yhat_i - ybar_i)^2 /
%                      max(s_i^2 / max(ybar_i^2,eps_y^2), eps_rv)
%
% IMPORTANT: s_i^2 is always the sample variance across replicates at the
% SAME time point. The raw condition uses the supplied experimental
% replicates; noise conditions use the artificial replicate sets.
%
% Required files on MATLAB path:
%   STAR_GenAlg_Model.m
%
% Expected CSV layout:
%   One time column and one GFP column for each of the nine 8 nM replicates.
%   Example: Time,Rep1,Rep2,...,Rep9
%
% Example (with automatic column identification):
%   run_star_nine_scenario_ga('STAR_Data3011.csv');
%
% Example (explicit columns, safest when the CSV contains multiple conditions):
%   run_star_nine_scenario_ga('STAR_Data3011.csv', ...
%       'TimeColumn','Time', ...
%       'GFPColumns',{'STAR8_Rep1','STAR8_Rep2','STAR8_Rep3','STAR8_Rep4', ...
%                     'STAR8_Rep5','STAR8_Rep6','STAR8_Rep7','STAR8_Rep8','STAR8_Rep9'});
%
% Diagnostic run before the full manuscript run:
%   run_star_nine_scenario_ga('STAR_Data3011.csv', ...
%       'NumRestarts',2,'PopulationSize',50,'MaxGenerations',30, ...
%       'OutputDirectory','STAR_nine_scenario_diagnostic','Display','iter');
%
% Manuscript-style run:
%   run_star_nine_scenario_ga('STAR_Data3011.csv', ...
%       'NumRestarts',30,'PopulationSize',100,'MaxGenerations',100, ...
%       'OutputDirectory','STAR_nine_scenario_results','Display','off');

    ip = inputParser;
    ip.addRequired('raw_data_file', @(x) ischar(x) || isstring(x));
    ip.addParameter('TimeColumn', [], @(x) isempty(x) || ischar(x) || isstring(x) || (isnumeric(x) && isscalar(x)));
    ip.addParameter('GFPColumns', [], @(x) isempty(x) || iscell(x) || isstring(x) || isnumeric(x));
    ip.addParameter('OutputDirectory', 'STAR_nine_scenario_results', @(x) ischar(x) || isstring(x));
    ip.addParameter('NumRestarts', 30, @(x) isnumeric(x) && isscalar(x) && x >= 1);
    ip.addParameter('PopulationSize', 100, @(x) isnumeric(x) && isscalar(x) && x >= 8);
    ip.addParameter('MaxGenerations', 100, @(x) isnumeric(x) && isscalar(x) && x >= 1);
    ip.addParameter('FunctionTolerance', 1e-8, @(x) isnumeric(x) && isscalar(x) && x > 0);
    ip.addParameter('InitialPopulationScale', 'log10', @(x) any(strcmpi(x, {'log10','linear'})));
    ip.addParameter('NoiseLevels', [0 0.20 0.40], @(x) isnumeric(x) && isvector(x) && all(x >= 0));
    ip.addParameter('NumArtificialReplicates', 6, @(x) isnumeric(x) && isscalar(x) && x >= 2);
    ip.addParameter('VarianceFloor', 1e-6, @(x) isnumeric(x) && isscalar(x) && x > 0);
    ip.addParameter('SignalFloor', 1e-6, @(x) isnumeric(x) && isscalar(x) && x > 0);
    ip.addParameter('RelativeVarianceFloor', 1e-6, @(x) isnumeric(x) && isscalar(x) && x > 0);
    ip.addParameter('RandomSeed', 20260904, @(x) isnumeric(x) && isscalar(x));
    ip.addParameter('NoiseRandomSeed', 20260905, @(x) isnumeric(x) && isscalar(x));
    ip.addParameter('Resume', true, @(x) islogical(x) && isscalar(x));
    ip.addParameter('Display', 'off', @(x) any(strcmpi(x, {'off','final','iter'})));
    ip.parse(raw_data_file, varargin{:});
    settings = ip.Results;

    assert(exist('STAR_GenAlg_Model.m','file') == 2, ...
        'STAR_GenAlg_Model.m must be available on the MATLAB path.');
    assert(exist('ga','file') == 2, ...
        'The Global Optimization Toolbox function ga is required.');

    [time_min, raw_replicates, input_metadata] = read_star_replicates( ...
        char(raw_data_file), settings.TimeColumn, settings.GFPColumns);
    [time_min, raw_replicates] = validate_and_sort_input(time_min, raw_replicates);
    n_time = numel(time_min);
    fit_mask = time_min > 0;
    assert(any(fit_mask), 'At least one sampled time must be greater than zero.');

    scenarios = build_scenarios(raw_replicates, time_min, settings);
    scenario_names = {scenarios.name};
    objectives = {'no_variance','variance','relative_variance'};

    % Bounds reproduce the active bounds in the supplied STAR_GA_Fitting.m.
    % Ordering: alpha_s, delta_s, delta_m, beta_s, alpha_m, Ki, Ke, alpha_gm.
    lb = [1e-1, 1e-4, 1e-4, 1e3, 1e-1, 1e-3, 1e-3, 1e-3];
    ub = [1e1,  1e0,  1e0,  1e8, 1e2,  1e-1, 1e-1, 1e-1];
    param_names = {'alpha_s','deg_s','deg_m','beta_s','alpha_m','K_i','K_e','alpha_gm'};

    % Numerical STAR condition, identical to the original fitting files.
    global par
    par = struct('PYtot',0.5e-9,'Ps',8e-9);
    common = struct( ...
        'time_sec', 60.*time_min(:), ...
        'fit_mask', fit_mask(:), ...
        'x0', zeros(5,1), ...
        'ode_options', odeset('RelTol',1e-8,'AbsTol',1e-10,'NonNegative',1:5), ...
        'variance_floor', settings.VarianceFloor, ...
        'signal_floor', settings.SignalFloor, ...
        'relative_variance_floor', settings.RelativeVarianceFloor);

    output_dir = char(settings.OutputDirectory);
    if ~isfolder(output_dir), mkdir(output_dir); end
    checkpoint_file = fullfile(output_dir,'STAR_nine_scenario_checkpoint.mat');
    if settings.Resume && isfile(checkpoint_file)
        previous = load(checkpoint_file,'run_records');
        if isfield(previous,'run_records')
            run_records = previous.run_records;
        else
            run_records = empty_run_record_array();
        end
    else
        run_records = empty_run_record_array();
    end

    fprintf('\n=== STAR: NINE-SCENARIO, THREE-OBJECTIVE FITTING ===\n');
    fprintf('Raw replicates: %d; time points: %d; time range: %.3g to %.3g min\n', ...
        size(raw_replicates,1),n_time,min(time_min),max(time_min));
    fprintf('Scenarios: %s\n',strjoin(scenario_names,', '));
    fprintf('Objectives: No Variance | Variance | Relative Variance\n');
    fprintf('Independent GA runs/scenario/objective: %d\n\n',settings.NumRestarts);

    for scenario_index = 1:numel(scenarios)
        scenario = scenarios(scenario_index);
        fprintf('%s\n', scenario.display_name);

        for objective_index = 1:numel(objectives)
            objective_type = objectives{objective_index};
            for restart_id = 1:settings.NumRestarts
                if record_exists(run_records, scenario.name, objective_type, restart_id)
                    fprintf('  %-18s run %2d: already complete; skipping.\n',objective_type,restart_id);
                    continue;
                end

                % Every objective within one scenario/restart receives the
                % same explicit starting population and random stream.
                run_seed = settings.RandomSeed + 10000*scenario_index + restart_id;
                rng(run_seed,'twister');
                initial_population = sample_initial_population(lb,ub,settings.PopulationSize, ...
                    settings.InitialPopulationScale);
                p0 = initial_population(1,:);
                objective_handle = @(p) star_objective(p,objective_type,scenario,common);
                ga_options = optimoptions('ga', ...
                    'PopulationSize',settings.PopulationSize, ...
                    'MaxGenerations',settings.MaxGenerations, ...
                    'FunctionTolerance',settings.FunctionTolerance, ...
                    'InitialPopulationMatrix',initial_population, ...
                    'Display',settings.Display, ...
                    'PlotFcn',[]);

                record = new_run_record(scenario.name,scenario.display_name,objective_type,restart_id,p0,run_seed);
                start_time = tic;
                try
                    rng(run_seed,'twister');
                    [p_opt,fval,exitflag,output] = ga(objective_handle,numel(lb), ...
                        [],[],[],[],lb,ub,[],ga_options);
                    [training_objective,training_unweighted_sse,prediction] = ...
                        star_objective(p_opt,objective_type,scenario,common);
                    reference_residual = prediction(common.fit_mask) - scenario.raw_reference_mean(common.fit_mask);
                    reference_sse = sum(reference_residual.^2);

                    record.p_opt = p_opt(:)';
                    record.fval = fval;
                    record.training_objective = training_objective;
                    record.training_unweighted_sse = training_unweighted_sse;
                    record.raw_reference_sse = reference_sse;
                    record.exitflag = exitflag;
                    record.output = output;
                    record.prediction = prediction(:)';
                    record.status = 'success';
                    record.message = '';
                    fprintf('  %-18s run %2d: J=%.4e | raw-reference SSE=%.4e | exit=%d\n', ...
                        objective_type,restart_id,training_objective,reference_sse,exitflag);
                catch ME
                    record.p_opt = nan(1,numel(lb));
                    record.fval = inf;
                    record.training_objective = inf;
                    record.training_unweighted_sse = inf;
                    record.raw_reference_sse = inf;
                    record.exitflag = -999;
                    record.output = struct();
                    record.prediction = nan(1,n_time);
                    record.status = 'failed';
                    record.message = sprintf('%s: %s',ME.identifier,ME.message);
                    fprintf('  %-18s run %2d: FAILED (%s)\n',objective_type,restart_id,ME.message);
                end
                record.runtime_seconds = toc(start_time);
                record.scenario = scenario;
                run_records(end+1) = record; %#ok<AGROW>
                save(checkpoint_file,'run_records','settings','input_metadata','lb','ub','param_names','-v7.3');
            end
        end
    end

    run_summary = summarize_runs(run_records,scenario_names,objectives,param_names,lb,ub,settings,input_metadata);
    save(fullfile(output_dir,'STAR_nine_scenario_results.mat'), ...
        'run_records','run_summary','settings','input_metadata','lb','ub','param_names','-v7.3');
    write_run_summary(run_summary,fullfile(output_dir,'STAR_nine_scenario_summary.csv'));
    fprintf('\nCompleted STAR fitting. Results saved in: %s\n',output_dir);
end

function [time_min,replicates,metadata] = read_star_replicates(filename,time_column,gfp_columns)
% Read a CSV with one time vector and replicate GFP columns.
    assert(isfile(filename),'Input file not found: %s',filename);
    T = readtable(filename,'VariableNamingRule','preserve');
    names = T.Properties.VariableNames;
    n_columns = width(T);

    if isempty(time_column)
        candidates = find(contains(lower(string(names)),{'time','min','hour'}));
        if isempty(candidates)
            time_index = 1;
            warning('No time-like header was found; using the first CSV column as time.');
        else
            time_index = candidates(1);
        end
    else
        time_index = resolve_columns(time_column,names,n_columns,'TimeColumn');
    end
    time_min = numeric_table_column(T,time_index,'time');

    if isempty(gfp_columns)
        candidate_indices = setdiff(1:n_columns,time_index);
        is_numeric = false(size(candidate_indices));
        for i = 1:numel(candidate_indices)
            values = T{:,candidate_indices(i)};
            is_numeric(i) = isnumeric(values) || islogical(values);
        end
        gfp_indices = candidate_indices(is_numeric);
    else
        gfp_indices = resolve_columns(gfp_columns,names,n_columns,'GFPColumns');
    end
    assert(numel(gfp_indices) >= 2, ...
        'At least two GFP replicate columns are required to estimate variance.');

    replicates = nan(numel(time_min),numel(gfp_indices));
    for i = 1:numel(gfp_indices)
        replicates(:,i) = numeric_table_column(T,gfp_indices(i),sprintf('GFP replicate %d',i));
    end
    replicates = replicates';  % output: replicates x time points

    metadata = struct();
    metadata.source_file = filename;
    metadata.time_column = names{time_index};
    metadata.gfp_columns = names(gfp_indices);
end

function index = resolve_columns(specification,names,n_columns,argument_name)
    if isnumeric(specification)
        index = specification(:)';
        assert(all(index >= 1 & index <= n_columns & mod(index,1) == 0), ...
            '%s contains an invalid numeric column index.',argument_name);
    else
        requested = cellstr(string(specification));
        index = zeros(1,numel(requested));
        for i = 1:numel(requested)
            hit = find(strcmpi(names,requested{i}),1);
            assert(~isempty(hit),'%s column "%s" was not found in the CSV.',argument_name,requested{i});
            index(i) = hit;
        end
    end
end

function values = numeric_table_column(T,index,label)
    values = T{:,index};
    if iscell(values) || isstring(values) || iscategorical(values)
        values = str2double(string(values));
    end
    assert(isnumeric(values) || islogical(values),'The %s column is not numeric.',label);
    values = double(values(:));
end

function [time_min,replicates] = validate_and_sort_input(time_min,replicates)
    valid = isfinite(time_min) & all(isfinite(replicates),1)';
    time_min = time_min(valid);
    replicates = replicates(:,valid);
    assert(numel(time_min) >= 3,'At least three complete time points are required.');
    [time_min,order] = sort(time_min(:));
    replicates = replicates(:,order);
    assert(all(diff(time_min) > 0), ...
        'Each sampled time must appear once in the CSV; duplicate times were found.');
end

function scenarios = build_scenarios(raw_replicates,time_min,settings)
    raw_mean = mean(raw_replicates,1)';
    raw_variance = var(raw_replicates,0,1)';
    scenarios = repmat(struct(),1,numel(settings.NoiseLevels));

    for i = 1:numel(settings.NoiseLevels)
        rho = settings.NoiseLevels(i);
        if rho == 0
            observed_replicates = raw_replicates;
            scenario_name = 'raw';
            display_name = 'Raw data';
        else
            % Equation (9) in the manuscript: y_art = max(0, ybar + eta),
            % eta ~ N(0, (rho*ybar)^2). Six artificial replicates are used.
            rng(settings.NoiseRandomSeed + round(1000*rho),'twister');
            noise_sd = rho .* raw_mean(:)';
            observed_replicates = raw_mean(:)' + ...
                randn(settings.NumArtificialReplicates,numel(time_min)) .* noise_sd;
            observed_replicates = max(observed_replicates,0);
            scenario_name = sprintf('noise_%02d',round(100*rho));
            display_name = sprintf('Noise = %d%%',round(100*rho));
        end

        scenario = struct();
        scenario.name = scenario_name;
        scenario.display_name = display_name;
        scenario.noise_fraction = rho;
        scenario.time_min = time_min(:);
        scenario.replicates = observed_replicates;
        scenario.mean_data = mean(observed_replicates,1)';
        scenario.sample_variance = var(observed_replicates,0,1)';
        scenario.sample_sd = sqrt(max(scenario.sample_variance,0));
        scenario.raw_reference_mean = raw_mean;
        scenario.raw_reference_variance = raw_variance;
        scenarios(i) = scenario;
    end
end

function [objective_value,unweighted_sse,prediction] = star_objective(p,objective_type,scenario,common)
    global par
    try
        [t_out,x_out] = ode23s(@(t,x) STAR_GenAlg_Model(t,x,p), ...
            common.time_sec,common.x0,common.ode_options);
        if numel(t_out) ~= numel(common.time_sec) || size(x_out,2) < 5 || ...
                ~isreal(x_out) || any(~isfinite(x_out(:)))
            error('Invalid ODE solution.');
        end
        prediction = x_out(:,5).*1e6;
        residual = prediction - scenario.mean_data;
        valid = common.fit_mask & isfinite(residual) & isfinite(scenario.sample_variance);
        if ~all(isfinite(prediction)) || ~any(valid)
            error('No valid residual values are available.');
        end

        residual_squared = residual(valid).^2;
        unweighted_sse = sum(residual_squared);
        switch lower(objective_type)
            case 'no_variance'
                objective_value = unweighted_sse;
            case 'variance'
                denominator = max(scenario.sample_variance(valid),common.variance_floor);
                objective_value = sum(residual_squared ./ denominator);
            case 'relative_variance'
                relative_variance = scenario.sample_variance(valid) ./ ...
                    max(scenario.mean_data(valid).^2,common.signal_floor);
                denominator = max(relative_variance,common.relative_variance_floor);
                objective_value = sum(residual_squared ./ denominator);
            otherwise
                error('Unknown objective type: %s',objective_type);
        end
        if ~isreal(objective_value) || ~isfinite(objective_value)
            error('Objective value is invalid.');
        end
    catch
        objective_value = 1e10;
        unweighted_sse = 1e10;
        prediction = nan(numel(common.time_sec),1);
    end
end

function population = sample_initial_population(lb,ub,population_size,scale)
    n_parameters = numel(lb);
    switch lower(scale)
        case 'log10'
            population = 10 .^ (log10(lb) + rand(population_size,n_parameters) .* (log10(ub)-log10(lb)));
        case 'linear'
            population = lb + rand(population_size,n_parameters) .* (ub-lb);
        otherwise
            error('Unknown InitialPopulationScale: %s',scale);
    end
end

function tf = record_exists(records,scenario_name,objective_type,restart_id)
    if isempty(records), tf = false; return; end
    tf = any(strcmp({records.scenario_name},scenario_name) & ...
        strcmp({records.objective_type},objective_type) & ...
        [records.restart_id] == restart_id);
end

function record = new_run_record(scenario_name,scenario_display_name,objective_type,restart_id,p0,run_seed)
    record = struct('scenario_name',scenario_name, ...
        'scenario_display_name',scenario_display_name, ...
        'objective_type',objective_type, ...
        'restart_id',restart_id, ...
        'p0',p0, ...
        'random_seed',run_seed, ...
        'p_opt',[], ...
        'fval',[], ...
        'training_objective',[], ...
        'training_unweighted_sse',[], ...
        'raw_reference_sse',[], ...
        'exitflag',[], ...
        'output',[], ...
        'prediction',[], ...
        'runtime_seconds',[], ...
        'status','', ...
        'message','', ...
        'scenario',[]);
end

function records = empty_run_record_array()
    prototype = new_run_record('','','',[],[],[]);
    records = prototype([]);
end

function summary = summarize_runs(records,scenario_names,objectives,param_names,lb,ub,settings,input_metadata)
    summary = struct();
    summary.scenario_names = scenario_names;
    summary.objectives = objectives;
    summary.parameter_names = param_names;
    summary.lower_bounds = lb;
    summary.upper_bounds = ub;
    summary.settings = settings;
    summary.input_metadata = input_metadata;
    summary.by_scenario = struct();

    for i = 1:numel(scenario_names)
        scenario_name = scenario_names{i};
        scenario_summary = struct();
        for j = 1:numel(objectives)
            objective_type = objectives{j};
            selected = select_successful_records(records,scenario_name,objective_type);
            result = struct();
            result.n_successful_runs = numel(selected);
            if isempty(selected)
                result.best_by_training_objective = [];
                result.best_by_raw_reference_sse = [];
            else
                [~,idx_train] = min([selected.training_objective]);
                [~,idx_reference] = min([selected.raw_reference_sse]);
                result.best_by_training_objective = selected(idx_train);
                result.best_by_raw_reference_sse = selected(idx_reference);
                result.parameter_matrix = vertcat(selected.p_opt);
                result.training_objective = [selected.training_objective]';
                result.training_unweighted_sse = [selected.training_unweighted_sse]';
                result.raw_reference_sse = [selected.raw_reference_sse]';
                result.runtime_seconds = [selected.runtime_seconds]';
            end
            scenario_summary.(objective_type) = result;
        end
        summary.by_scenario.(scenario_name) = scenario_summary;
    end
end

function selected = select_successful_records(records,scenario_name,objective_type)
    idx = strcmp({records.scenario_name},scenario_name) & ...
        strcmp({records.objective_type},objective_type) & strcmp({records.status},'success');
    selected = records(idx);
end

function write_run_summary(summary,output_file)
    headers = {'Scenario','Objective','SuccessfulRuns','BestTrainingObjective', ...
        'TrainingSSEofBestTrainingRun','RawReferenceSSEofBestTrainingRun', ...
        'BestRawReferenceSSE'};
    rows = {};
    for i = 1:numel(summary.scenario_names)
        scenario_name = summary.scenario_names{i};
        for j = 1:numel(summary.objectives)
            objective_type = summary.objectives{j};
            result = summary.by_scenario.(scenario_name).(objective_type);
            if isempty(result.best_by_training_objective)
                rows(end+1,:) = {scenario_name,objective_type,0,NaN,NaN,NaN,NaN}; %#ok<AGROW>
            else
                best_training = result.best_by_training_objective;
                best_reference = result.best_by_raw_reference_sse;
                rows(end+1,:) = {scenario_name,objective_type,result.n_successful_runs, ...
                    best_training.training_objective,best_training.training_unweighted_sse, ...
                    best_training.raw_reference_sse,best_reference.raw_reference_sse}; %#ok<AGROW>
            end
        end
    end
    writecell([headers;rows],output_file);
end

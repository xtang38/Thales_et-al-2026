function run_summary = run_STAR_synthetic_three_objective_ga(varargin)
%RUN_STAR_SYNTHETIC_THREE_OBJECTIVE_GA Fit 100 STAR synthetic datasets.
%
% This is the STAR counterpart of the three-objective workflow used in the
% second manuscript study. It fits the supplied 100 synthetic datasets at the
% single 8 nM STAR condition. Dataset d has three replicate trajectories in
% Simu_Traje((d-1)*3+(1:3),:). The model is calibrated to their mean.
%
% Objective functions
% -------------------
%   No Variance:
%       J_SSE = sum_i [GFP_sim(t_i;theta) - mean_d(t_i)]^2
%
%   Variance:
%       J_Var = sum_i [GFP_sim(t_i;theta) - mean_d(t_i)]^2 / v_d(t_i)
%
%   Relative Variance:
%       J_RV = sum_i [GFP_sim(t_i;theta) - mean_d(t_i)]^2 /
%                          [v_d(t_i) / mean_d(t_i)^2]
%
% v_d(t_i) is read from variance_Data.xlsx, which contains the generated,
% time-dependent variance trajectory for each synthetic dataset. This is the
% correct variance input for the controlled benchmark. The three replicate
% trajectories remain available for visualization and for checking that their
% empirical sample variance reflects the imposed variance pattern.
%
% The first 100 worksheet rows are used by default because these are the rows
% indexed by the supplied STAR_GenAlg_Obj.m script. Multiplying all v_d(t_i)
% within a dataset by a constant does not change the fitted parameter vector,
% so the original row-normalization convention is available as an option.
%
% Requires: Global Optimization Toolbox and STAR_GenAlg_Model.m on MATLAB path.
%
% Quick diagnostic:
%   run_STAR_synthetic_three_objective_ga('DatasetIndices',1:3, ...
%       'PopulationSize',50,'MaxGenerations',30,'Display','iter');
%
% Manuscript run:
%   run_STAR_synthetic_three_objective_ga('DatasetIndices',1:100, ...
%       'NumRestarts',1,'PopulationSize',100,'MaxGenerations',100);

    ip = inputParser;
    ip.addParameter('DataFile','Simulated_Data_Jan22_2025.mat',@(x)ischar(x)||isstring(x));
    ip.addParameter('VarianceFile','variance_Data.xlsx',@(x)ischar(x)||isstring(x));
    ip.addParameter('VarianceRows',1:100,@(x)isnumeric(x)&&isvector(x));
    ip.addParameter('DatasetIndices',1:100,@(x)isnumeric(x)&&isvector(x));
    ip.addParameter('OutputDirectory','STAR_synthetic_three_objective_results',@(x)ischar(x)||isstring(x));
    ip.addParameter('NumRestarts',1,@(x)isnumeric(x)&&isscalar(x)&&x>=1);
    ip.addParameter('PopulationSize',100,@(x)isnumeric(x)&&isscalar(x)&&x>=8);
    ip.addParameter('MaxGenerations',100,@(x)isnumeric(x)&&isscalar(x)&&x>=1);
    ip.addParameter('FunctionTolerance',1e-8,@(x)isnumeric(x)&&isscalar(x)&&x>0);
    ip.addParameter('InitialPopulationScale','log10',@(x)any(strcmpi(x,{'log10','linear'})));
    ip.addParameter('NormalizeVarianceRows',true,@(x)islogical(x)&&isscalar(x));
    ip.addParameter('VarianceFloor',1e-12,@(x)isnumeric(x)&&isscalar(x)&&x>0);
    ip.addParameter('SignalFloor',1e-6,@(x)isnumeric(x)&&isscalar(x)&&x>0);
    ip.addParameter('RelativeVarianceFloor',1e-12,@(x)isnumeric(x)&&isscalar(x)&&x>0);
    ip.addParameter('ExcludeTimeZero',true,@(x)islogical(x)&&isscalar(x));
    ip.addParameter('RandomSeed',20260904,@(x)isnumeric(x)&&isscalar(x));
    ip.addParameter('Resume',true,@(x)islogical(x)&&isscalar(x));
    ip.addParameter('Display','off',@(x)any(strcmpi(x,{'off','final','iter'})));
    ip.parse(varargin{:});
    settings = ip.Results;

    assert(exist('STAR_GenAlg_Model.m','file') == 2, ...
        'STAR_GenAlg_Model.m must be on the MATLAB path.');
    assert(exist('ga','file') == 2, ...
        'This function requires the Global Optimization Toolbox function ga.');

    input_data = load(settings.DataFile,'Simu_Traje','Simu_Ave','Simu_t');
    assert(isfield(input_data,'Simu_Traje') && isfield(input_data,'Simu_t'), ...
        'DataFile must contain Simu_Traje and Simu_t.');
    variance_matrix = readmatrix(settings.VarianceFile);
    assert(isnumeric(variance_matrix) && all(isfinite(variance_matrix(:))), ...
        'VarianceFile must contain a finite numeric matrix.');

    time_min = double(input_data.Simu_t(:));
    n_time = numel(time_min);
    n_replicates = 3;
    n_datasets = size(input_data.Simu_Traje,1)/n_replicates;
    assert(mod(size(input_data.Simu_Traje,1),n_replicates)==0, ...
        'Simu_Traje rows must form groups of three replicate trajectories.');
    assert(size(input_data.Simu_Traje,2)==n_time, ...
        'Simu_Traje columns must match the length of Simu_t.');
    assert(numel(settings.VarianceRows) >= n_datasets, ...
        'VarianceRows must contain at least one row for every synthetic dataset.');
    assert(all(settings.VarianceRows>=1 & settings.VarianceRows<=size(variance_matrix,1)), ...
        'VarianceRows contains an index outside the supplied variance workbook.');
    assert(size(variance_matrix,2)==n_time, ...
        'Variance workbook columns must match the length of Simu_t.');

    dataset_indices = unique(settings.DatasetIndices(:)');
    assert(all(dataset_indices>=1 & dataset_indices<=n_datasets & mod(dataset_indices,1)==0), ...
        'DatasetIndices must be integers from 1 through %d.',n_datasets);
    fit_mask = time_min > 0;
    if ~settings.ExcludeTimeZero, fit_mask = true(size(time_min)); end

    % The active bounds below exactly reproduce the bound vectors in
    % STAR_GA_Fitting.m. Parameter order is fixed throughout all outputs.
    lb = [1e-1,1e-4,1e-4,1e3,1e-1,1e-3,1e-3,1e-3];
    ub = [1e1, 1e0, 1e0, 1e8,1e2, 1e-1,1e-1,1e-1];
    param_names = {'alpha_s','deg_s','deg_m','beta_s','alpha_m','K_i','K_e','alpha_gm'};
    objectives = {'no_variance','variance','relative_variance'};

    global par
    par = struct('PYtot',0.5e-9,'Ps',8e-9);
    configuration = struct( ...
        'time_sec',60.*time_min, ...
        'fit_mask',fit_mask, ...
        'x0',zeros(5,1), ...
        'ode_options',odeset('RelTol',1e-8,'AbsTol',1e-10,'NonNegative',1:5), ...
        'variance_floor',settings.VarianceFloor, ...
        'signal_floor',settings.SignalFloor, ...
        'relative_variance_floor',settings.RelativeVarianceFloor);

    output_dir = char(settings.OutputDirectory);
    if ~isfolder(output_dir), mkdir(output_dir); end
    checkpoint_file = fullfile(output_dir,'STAR_synthetic_three_objective_checkpoint.mat');
    if settings.Resume && isfile(checkpoint_file)
        loaded = load(checkpoint_file,'run_records');
        if isfield(loaded,'run_records'), run_records = loaded.run_records; else, run_records = empty_record_array(); end
    else
        run_records = empty_record_array();
    end

    fprintf('\n=== STAR SYNTHETIC BENCHMARK: THREE OBJECTIVES ===\n');
    fprintf('Synthetic datasets: %d; replicates/dataset: %d; sampled times: %d\n', ...
        n_datasets,n_replicates,n_time);
    fprintf('Variance source: %s (rows %d through %d)\n', ...
        settings.VarianceFile,settings.VarianceRows(1),settings.VarianceRows(n_datasets));
    fprintf('GA runs per dataset/objective: %d\n\n',settings.NumRestarts);

    for dataset_id = dataset_indices
        replicate_rows = (dataset_id-1)*n_replicates + (1:n_replicates);
        replicate_data = double(input_data.Simu_Traje(replicate_rows,:));
        mean_data = mean(replicate_data,1)';
        empirical_variance = var(replicate_data,0,1)';
        supplied_variance = variance_matrix(settings.VarianceRows(dataset_id),:)';
        assert(all(isfinite(mean_data)) && all(isfinite(supplied_variance)) && all(supplied_variance>=0), ...
            'Dataset %d has invalid data or supplied variance values.',dataset_id);

        if settings.NormalizeVarianceRows
            normalizer = max(supplied_variance(fit_mask));
            assert(normalizer > 0,'Dataset %d has zero supplied variance at every fitted time.',dataset_id);
            supplied_variance = supplied_variance ./ normalizer;
        end

        data_summary = struct( ...
            'dataset_id',dataset_id, ...
            'time_min',time_min, ...
            'replicates',replicate_data, ...
            'mean_data',mean_data, ...
            'empirical_variance',empirical_variance, ...
            'supplied_variance',supplied_variance);
        fprintf('Dataset %d/%d\n',dataset_id,n_datasets);

        for objective_index = 1:numel(objectives)
            objective_type = objectives{objective_index};
            for restart_id = 1:settings.NumRestarts
                if record_exists(run_records,dataset_id,objective_type,restart_id)
                    fprintf('  %-18s restart %d: already complete; skipping.\n',objective_type,restart_id);
                    continue;
                end

                % Same initial population and RNG seed for all three objectives
                % within a dataset/restart provides a fair GA comparison.
                run_seed = settings.RandomSeed + 10000*dataset_id + restart_id;
                rng(run_seed,'twister');
                initial_population = sample_initial_population(lb,ub,settings.PopulationSize,settings.InitialPopulationScale);
                p0 = initial_population(1,:);
                objective_handle = @(p) STAR_synthetic_objective(p,objective_type,data_summary,configuration);
                ga_options = optimoptions('ga', ...
                    'PopulationSize',settings.PopulationSize, ...
                    'MaxGenerations',settings.MaxGenerations, ...
                    'FunctionTolerance',settings.FunctionTolerance, ...
                    'InitialPopulationMatrix',initial_population, ...
                    'Display',settings.Display,'PlotFcn',[]);

                record = new_record(dataset_id,objective_type,restart_id,p0,run_seed);
                tic_id = tic;
                try
                    rng(run_seed,'twister');
                    [p_opt,fval,exitflag,output] = ga(objective_handle,numel(lb),[],[],[],[],lb,ub,[],ga_options);
                    [training_objective,common_sse,prediction] = ...
                        STAR_synthetic_objective(p_opt,objective_type,data_summary,configuration);
                    record.p_opt = p_opt(:)';
                    record.training_objective = training_objective;
                    record.common_sse = common_sse;
                    record.fval = fval;
                    record.exitflag = exitflag;
                    record.output = output;
                    record.prediction = prediction(:)';
                    record.status = 'success';
                    record.message = '';
                    fprintf('  %-18s restart %d: J=%.4e; unweighted SSE=%.4e; exit=%d\n', ...
                        objective_type,restart_id,training_objective,common_sse,exitflag);
                catch ME
                    record.p_opt = nan(1,numel(lb));
                    record.training_objective = inf;
                    record.common_sse = inf;
                    record.fval = inf;
                    record.exitflag = -999;
                    record.output = struct();
                    record.prediction = nan(1,n_time);
                    record.status = 'failed';
                    record.message = sprintf('%s: %s',ME.identifier,ME.message);
                    fprintf('  %-18s restart %d: FAILED (%s)\n',objective_type,restart_id,ME.message);
                end
                record.runtime_seconds = toc(tic_id);
                record.data_summary = data_summary;
                run_records(end+1) = record; %#ok<AGROW>
                save(checkpoint_file,'run_records','settings','lb','ub','param_names','-v7.3');
            end
        end
    end

    run_summary = summarize_runs(run_records,objectives,param_names,lb,ub,settings);
    save(fullfile(output_dir,'STAR_synthetic_three_objective_results.mat'), ...
        'run_records','run_summary','settings','lb','ub','param_names','-v7.3');
    write_summary_csv(run_summary,fullfile(output_dir,'STAR_synthetic_three_objective_summary.csv'));
    fprintf('\nFinished STAR synthetic benchmark. Results saved in: %s\n',output_dir);
end

function [objective_value,common_sse,prediction] = STAR_synthetic_objective(p,objective_type,data_summary,configuration)
    global par
    try
        [t_out,x_out] = ode23s(@(t,x) STAR_GenAlg_Model(t,x,p), ...
            configuration.time_sec,configuration.x0,configuration.ode_options);
        if numel(t_out) ~= numel(configuration.time_sec) || size(x_out,2) < 5 || ...
                ~isreal(x_out) || any(~isfinite(x_out(:)))
            error('Invalid ODE solution.');
        end
        prediction = x_out(:,5).*1e6;
        residual = prediction - data_summary.mean_data;
        valid = configuration.fit_mask & isfinite(residual) & isfinite(data_summary.supplied_variance);
        if ~all(isfinite(prediction)) || ~any(valid), error('No valid residuals.'); end
        squared_residual = residual(valid).^2;
        common_sse = sum(squared_residual);
        switch lower(objective_type)
            case 'no_variance'
                objective_value = common_sse;
            case 'variance'
                denominator = max(data_summary.supplied_variance(valid),configuration.variance_floor);
                objective_value = sum(squared_residual./denominator);
            case 'relative_variance'
                relative_variance = data_summary.supplied_variance(valid)./ ...
                    max(data_summary.mean_data(valid).^2,configuration.signal_floor);
                denominator = max(relative_variance,configuration.relative_variance_floor);
                objective_value = sum(squared_residual./denominator);
            otherwise
                error('Unknown objective type: %s',objective_type);
        end
        if ~isreal(objective_value) || ~isfinite(objective_value), error('Invalid objective value.'); end
    catch
        objective_value = 1e10;
        common_sse = 1e10;
        prediction = nan(numel(configuration.time_sec),1);
    end
end

function population = sample_initial_population(lb,ub,population_size,scale)
    n_parameters = numel(lb);
    switch lower(scale)
        case 'log10'
            population = 10.^(log10(lb) + rand(population_size,n_parameters).*(log10(ub)-log10(lb)));
        case 'linear'
            population = lb + rand(population_size,n_parameters).*(ub-lb);
        otherwise
            error('Unknown InitialPopulationScale: %s',scale);
    end
end

function tf = record_exists(records,dataset_id,objective_type,restart_id)
    if isempty(records), tf = false; return; end
    tf = any([records.dataset_id] == dataset_id & strcmp({records.objective_type},objective_type) & ...
        [records.restart_id] == restart_id);
end

function record = new_record(dataset_id,objective_type,restart_id,p0,seed)
    record = struct('dataset_id',dataset_id,'objective_type',objective_type, ...
        'restart_id',restart_id,'p0',p0,'random_seed',seed,'p_opt',[], ...
        'training_objective',[],'common_sse',[],'fval',[],'exitflag',[], ...
        'output',[],'prediction',[],'runtime_seconds',[],'status','', ...
        'message','','data_summary',[]);
end

function records = empty_record_array()
    prototype = new_record([], '', [], [], []);
    records = prototype([]);
end

function summary = summarize_runs(records,objectives,param_names,lb,ub,settings)
    summary = struct('objectives',{objectives},'parameter_names',{param_names}, ...
        'lower_bounds',lb,'upper_bounds',ub,'settings',settings,'by_objective',struct());
    for i = 1:numel(objectives)
        objective_type = objectives{i};
        selected = records(strcmp({records.objective_type},objective_type) & strcmp({records.status},'success'));
        result = struct('n_successful_runs',numel(selected));
        if ~isempty(selected)
            [~,by_training] = min([selected.training_objective]);
            [~,by_sse] = min([selected.common_sse]);
            result.best_by_training_objective = selected(by_training);
            result.best_by_common_sse = selected(by_sse);
            result.parameter_matrix = vertcat(selected.p_opt);
            result.training_objective = [selected.training_objective]';
            result.common_sse = [selected.common_sse]';
        else
            result.best_by_training_objective = [];
            result.best_by_common_sse = [];
        end
        summary.by_objective.(objective_type) = result;
    end
end

function write_summary_csv(summary,output_file)
    headers = [{'Objective','SuccessfulRuns','BestTrainingObjective','BestCommonSSE'},summary.parameter_names];
    rows = cell(numel(summary.objectives),numel(headers));
    for i = 1:numel(summary.objectives)
        objective_type = summary.objectives{i};
        result = summary.by_objective.(objective_type);
        rows{i,1} = objective_type;
        rows{i,2} = result.n_successful_runs;
        if isempty(result.best_by_training_objective)
            rows{i,3} = NaN; rows{i,4} = NaN;
            rows(i,5:end) = num2cell(nan(1,numel(summary.parameter_names)));
        else
            best = result.best_by_training_objective;
            rows{i,3} = best.training_objective;
            rows{i,4} = best.common_sse;
            rows(i,5:end) = num2cell(best.p_opt);
        end
    end
    writecell([headers;rows],output_file);
end

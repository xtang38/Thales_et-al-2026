function plot_STAR_experimental_GA_results(results_file, varargin)
%PLOT_STAR_EXPERIMENTAL_GA_RESULTS Plot 8 nM STAR experimental fits.
%
% The three panels correspond to the three calibration objectives, exactly as
% the columns of the AND-gate/CRISPRi final figures. In each panel, the
% nine-replicate experimental mean is dashed, its ±1 sample-SD band is shaded,
% and the best selected STAR simulation is solid. The panel SSE is the shared
% unweighted SSE against the raw experimental replicate mean.
%
% Run after run_STAR_experimental_three_objective_ga:
%   plot_STAR_experimental_GA_results( ...
%       'STAR_experimental_three_objective_results/STAR_nine_scenario_results.mat');

    ip = inputParser;
    ip.addRequired('results_file',@(x)ischar(x)||isstring(x));
    ip.addParameter('OutputDirectory','',@(x)ischar(x)||isstring(x));
    ip.addParameter('SelectionCriterion','raw_reference_sse', ...
        @(x)any(strcmpi(x,{'raw_reference_sse','training_objective'})));
    ip.addParameter('Visible','on',@(x)any(strcmpi(x,{'on','off'})));
    ip.addParameter('SavePDF',false,@(x)islogical(x)&&isscalar(x));
    ip.parse(results_file,varargin{:});
    settings = ip.Results;

    source = load(settings.results_file,'run_records');
    assert(isfield(source,'run_records') && ~isempty(source.run_records), ...
        'No experimental STAR fitting records were found in %s.',settings.results_file);

    if isempty(settings.OutputDirectory)
        [parent_dir,~,~] = fileparts(settings.results_file);
        output_dir = fullfile(parent_dir,'plots');
    else
        output_dir = char(settings.OutputDirectory);
    end
    if ~isfolder(output_dir), mkdir(output_dir); end

    objectives = {'no_variance','variance','relative_variance'};
    labels = {'No Variance','Variance','Relative Variance'};
    gfp_color = [0.0000 0.4470 0.7410];

    fig = figure('Position',[10,10,1800,600],'Color','w','Visible',settings.Visible);
    for col = 1:3
        ax = subplot(1,3,col);
        hold(ax,'on');
        record = select_experimental_record(source.run_records,objectives{col},settings.SelectionCriterion);
        if isempty(record)
            text(ax,0.5,0.5,'No successful run','Units','normalized', ...
                'HorizontalAlignment','center','FontName','Arial','FontSize',12);
            style_axis(ax);
            continue;
        end

        scenario = record.scenario;
        time_min = scenario.time_min(:)';
        mean_trace = scenario.mean_data(:)';
        sd_trace = scenario.sample_sd(:)';
        prediction = record.prediction(:)';

        % Same shaded band / dashed experiment / solid model convention as
        % plot_CRISPRonly_GA_results.m and the supplied final figures.
        fill(ax,[time_min,fliplr(time_min)], ...
            [mean_trace-sd_trace,fliplr(mean_trace+sd_trace)], ...
            gfp_color,'FaceAlpha',0.20,'EdgeColor','none','HandleVisibility','off');
        plot(ax,time_min,mean_trace,'--','Color',gfp_color,'LineWidth',1.5, ...
            'DisplayName','GFP (Exp)');
        plot(ax,time_min,prediction,'-','Color',gfp_color,'LineWidth',2.5, ...
            'DisplayName','GFP (Sim)');

        text(ax,0.05,0.95,sprintf('STAR (8 nM) - %s\nSSE = %.4f', ...
            labels{col},record.raw_reference_sse), ...
            'Units','normalized','VerticalAlignment','top','HorizontalAlignment','left', ...
            'FontName','Arial','FontSize',12,'FontWeight','bold', ...
            'BackgroundColor','white','EdgeColor','none');
        xlabel(ax,'Time (min)','FontName','Arial','FontSize',16);
        ylabel(ax,'GFP fluorescence','FontName','Arial','FontSize',16);
        xlim(ax,[time_min(1),time_min(end)]);
        ymax = max([mean_trace+sd_trace,prediction],[],'omitnan');
        if isfinite(ymax) && ymax > 0, ylim(ax,[0,1.08*ymax]); end
        style_axis(ax);
    end

    legend_ax = axes('Position',[0,0,1,1],'Visible','off');
    hold(legend_ax,'on');
    h_exp = plot(legend_ax,NaN,NaN,'--','Color',gfp_color,'LineWidth',1.5);
    h_sim = plot(legend_ax,NaN,NaN,'-','Color',gfp_color,'LineWidth',2.5);
    legend(legend_ax,[h_exp,h_sim],{'GFP (Exp)','GFP (Sim)'}, ...
        'NumColumns',2,'Location','southoutside','FontSize',16, ...
        'FontName','Arial','FontWeight','bold','Box','on');
    sgtitle('STAR (8 nM): Best GA Results Across 3 Optimization Sets', ...
        'FontSize',18,'FontName','Arial','FontWeight','bold');

    output_stem = fullfile(output_dir,'STAR_Experimental_FinalPlot');
    exportgraphics(fig,[output_stem,'.png'],'Resolution',300);
    savefig(fig,[output_stem,'.fig']);
    if settings.SavePDF, exportgraphics(fig,[output_stem,'.pdf'],'ContentType','vector'); end
    fprintf('Experimental STAR plot saved as %s.png and %s.fig\n',output_stem,output_stem);
end

function record = select_experimental_record(records,objective_type,criterion)
    idx = strcmp({records.scenario_name},'raw') & strcmp({records.objective_type},objective_type) ...
        & strcmp({records.status},'success');
    candidates = records(idx);
    if isempty(candidates), record = []; return; end
    switch lower(criterion)
        case 'raw_reference_sse'
            [~,best_index] = min([candidates.raw_reference_sse]);
        case 'training_objective'
            [~,best_index] = min([candidates.training_objective]);
        otherwise
            error('Unknown SelectionCriterion: %s',criterion);
    end
    record = candidates(best_index);
end

function style_axis(ax)
    grid(ax,'on'); box(ax,'on');
    set(ax,'FontSize',12,'FontName','Arial','LineWidth',0.9,'Layer','top');
    ax.XAxisLocation = 'bottom';
    ax.YAxisLocation = 'left';
end
